# Construct Placement Law — `docs/construct.html`

**Status**: 🔒 LAW | **Updated**: 2026-11-16

The measured-surface contract for every asset placed in the Construct. This doc is
the authority for how things sit on things — if placement code and this doc disagree,
the doc wins and the code gets fixed.

> **File layout (2026-11-15):** `construct.html` is now a shell — the body lives in
> `docs/construct/01_shell.js` … `16_probe.js`, classic `<script defer>` files sharing
> one page-wide scope in load order (= the old top-down eval order; map in the HTML
> comment). Placement law lives mainly in `02_placed.js`, `03_tables.js`,
> `12_carry.js`, `13_place.js`, `15_boot.js`.

---

## 1. The PLACED record

`emitAsset(name, opts)` is the only way an asset enters the room. Every emit pushes
one record:

```js
{ name, kind, g,                 // asset id, ROUTES key ('item'|'vehicle'|'char'), THREE.Group
  tops, lb,                      // LOCAL column-top map (5mm keys) + local bounds
  x, z, rotY, y0, minB, vs,      // world transform: center xz, yaw, bottom-seat y, voxel bottom, voxelSize
  surf,                          // ROLE — see §2
  bbox,                          // world AABB footprint — footB(lb, x, z, rotY), kept LIVE by placeApply
  pickable, solids,              // E-takeable? / collision boxes
  source }                       // 'manifest' | 'extra'
```

`surfaceAt(host, wx, wz)` transforms a world point into the host's local column map
(through `g.getWorldPosition`/`getWorldQuaternion` — **world transform, never rec x/z**,
so parented assets like the car inside `carG` don't ghost their map at the origin)
and returns the highest column top near the point (±.07m scan radius).

## 2. Surface roles — `surf` is declared, never inferred

> BOSS law: *"tag these for specificity so we always know what's a surface and what rides surfaces."*

```js
surf = o.surf ?? (SURF_TYPES.has(m.assetType) || !o.pickable)
SURF_TYPES = { furniture, vehicle, room, building }   // voxel-editor department tag
```

| Role | Members | Rule |
|------|---------|------|
| `surf:true` | desks, door, doorframe, car, furniture, walls | **Floors only on other `surf` recs** — riders are invisible to its floor query, at emit and at re-seat |
| `surf:false` | gun, book, lamp, stamper, any pickable prop | **Conforms** to the highest top beneath it (surfaces, floor, or stacked riders) |

Rationale: hand-carryable (`pickable`) means rider by definition — a desk is never
E-taken, so `!pickable` marks it furniture even when its JSON `assetType` still says
`'prop'`. `o.surf` is the explicit override when a caller knows better.

## 3. The two enforcement levers

`placeSurf(wx, wz, skipSet, opt)` / `worldSurfaceAt(wx, wz, skip, opt)`:

```js
opt.surfOnly   // true → candidates filtered to rec.surf — furniture can never land on a rider
opt.cap        // tops above cap don't count — settle-only re-seat, nothing ever climbs
```

**Where each applies:**

| Site | Call | Effect |
|------|------|--------|
| `emitAsset` `seatY:'auto'` | conform + role | extras land on top of what's there; furniture ignores riders |
| Boot fixpoint re-seat | `surfOnly: p.surf, cap: p.y0+.01` | every item re-derives height on the final layout — **settle-only, descending order** |
| `B` re-seat | `surfOnly: p.surf` | deliberate re-seat conforms within role |
| `/cmd move` | `surfOnly: p.surf` | agent move seats deliberately |
| `settleOrphans` | `surfOnly: q.surf` | orphan drop also can't land furniture on a rider |
| `placeSpot` (drag ghost) | `surfOnly: sel.surf` | the preview obeys the same law |

**Frame law**: every sweep above speaks world coords — a rec whose `g.parent !== scene`
(parked cars ride `miniG`, the showroom car rides `carG`) stores parent-local `x/z/y0`, so
subject-side sweeps skip it outright (boot fixpoint, `settleOrphans`). Host-side reads stay
legal: `surfaceAt` uses the world transform, so riders still seat on a parked car's roof.
(Skipping them was the `CONSTRUCT_PARKED_CAR_WORLD_SWEEP_DROP` fix — an unguarded sweep
seated a parked car to `y0=0`, slab-floor = tabletop.)

**The bug class this kills** (all observed live): a desk emitting onto a floating
passenger's stale top; a desk re-seating onto the grounded passenger's own height;
door↔frame leapfrogging +.85m per commit; any host ratcheting on its own cargo.
A rider top can never host furniture (`surfOnly`), and no top can ever be `≤` an
item's bottom while being inside it (`cap`) — both failure modes are impossible by
declaration, not by tuning.

## 4. Boot restore order

`ready.then`:

1. **Tombstones** (`dvm_del`) — deleted manifest items removed first (a dead host
   must not seat anything).
2. **Overrides** (`dvm_place`) — `placeApply` lands manifest items at saved x/z/rotY.
   Overrides are **name-keyed WORLD coordinates** — so any rec whose `x/z` are
   parent-local (`_parked` scenery, anything emitted under `miniG`/a group) must
   never participate: skipped at save AND at apply, or a parked car's cell coords
   stamp onto every rec sharing the asset name (the spinner displacement —
   `PARKED_REC_NAME_OVERRIDE_DISPLACEMENT.md`). Tombstones, `liftRiders`, and the
   agent/`__place` by-name verbs (`move`/`del`/`grab`/`take`) skip `_parked` for
   the same reason — parked scenery is placed by the table's street law, not by
   hands. Apply happens **only at the same manifest rev**: a spec may carry `mv` (default 0); the
   save stores the item's `mv` and the override applies only when `o.mv === p.mv`.
   Bumping a spec's `mv` (an authored reposition) invalidates just that item's
   stale save — unversioned items keep their saved spots. Non-mount saves carry
   `y` — **the placed seat** — restored to `p.y0` before `placeApply` so the
   re-seat cap honors where the item actually stood, not its emit height.
3. **Lifts** (`dvm_lift:<id>`) — `tableLiftSet` restores each saved piston height
   AFTER overrides and BEFORE extras: `liftRiders` bumps anything standing at or
   above the old top by `dy` — saved seats ride the lift like live ones. (The
   restore is deferred out of eval — `liftRiders` reaches late-bound helpers;
   a boot-time call keeps the deferral and pins the order.)
4. **Mini mounts** — `mountModel` is async (stasset fetch+parse); boot awaits
   `Promise.all(TABLES.map(t => t._mountP))` before extras/fixpoint read `tops`.
   Un-awaited, a slow load lets a roof seat cap down to felt — the race that
   floored saved `.7475` pads to `.26` (CONSTRUCT_MOUNT_PROMISE_TOPS_RACE).
   `_mountP` covers the whole street: on the block table the boot chain runs
   `emitRing` → `mountParked` (cars on the static ring) → `mountModel`
   (the interior core), and `emitBlock` still awaits `mountParked`'s
   `Promise.all` of the per-car `vehFetch`+`emitAsset` chains on ring-less
   hosts — so an extra saved on a parked car's roof reads the car, not the
   road under it.
5. **Extras** (`dvm_extra`) — emit with `seatY:'auto'` → conform onto the final
   (already-lifted, mounted) layout.
6. **Fixpoint re-seat** (≤4 passes, descending y0) — every item settles:
   `surfOnly: p.surf, cap: p.y0 + .01`. Hosts correct first; passengers see the
   corrected tops. Converges when a pass moves nothing.
7. `refreshSolids()`, warm-up compile, `__warmDone`.

## 5. Persistence keys

| Key | Contents |
|-----|----------|
| `dvm_place` | `{name: {x,z,rotY,mv,y?,tilt?,mount?}}` — manifest overrides (`y` = the placed seat for non-mounts — the re-seat cap honors it; `mv` gates stale revs; `tilt` = the item's saved GRIP `{s,f}`, restored to hand on pickup — placed poses stay level/mounted) |
| `dvm_extra` | `[{name,kind,pickable,solids,x,z,rotY,y?,tilt?}]` — pasted/agent-emitted items (`tilt` = saved grip; `y` = saved seat, informational — extras still emit `seatY:'auto'`) |
| `dvm_del` | `[name]` — manifest tombstones |
| `dvm_fol` | follower roster (CHAIR survives F5) |
| `dvm_live` | `'1'` → live bridge auto-resumes after reload |

`placeSave()` writes all three after every completed move/drop/paste/delete/undo.

## 6. Held items — carry + orientation

`takeIt(p)` lifts a `pickable` rec; the group rides `.38m` ahead of the camera
each frame. `dropTarget()` marches the aim ray (`.08 → 2.4`, `.06` steps) until
`py ≤ surface+.02` — that march runs `placeSurf` per step, so:

- **Perf law**: `placeSurf` rejects by `p.bbox` before any column scan
  (`.12` pad covers the `.07` disc + `.05` footprint pad). Parented recs
  (`g.parent !== scene`, e.g. the car in `carG`) are exempt — their bbox is
  parent-local. `tops` keys are **numeric** (`TOPK(ix,iz)`) — string keys in a
  per-frame hot loop are GC churn. The pre-reject march ran ~39 steps × every
  host's ~841-cell scan with string concats — that was the carry-walk hitch.
- **Orientation law**: `held.g.quaternion = qYaw(facing) × qSnap × qFree`.
  - Axis snaps: 15° counters per axis — `, .` yaw · `[ ]` pitch · `; '` roll.
    A snap press clears `heldFree` — **axis rotation resets free rotation**, so
    level is always reachable.
  - `0` = LEVEL: all counters + tumble to identity → exactly authored-upright.
  - `G` + mouse = free trackball tumble (world X/Y); camera look is suspended
    while `G` is held.
  - `placeIt` persists `rotY = yaw + snapYaw` (normalized); pitch/roll drop —
    **placed items always seat level** because `tops`/`bbox` are authored-
    upright maps. The lean is a grip state, never a placed pose.
  - **Grip memory + persistence**: `placeIt` stashes the held pose
    (`p._snap`, `p._free`) on the rec and `takeIt` restores it — set a thing
    down, pick it back up, and it returns in the pose you last held it (the
    yaw chain stays continuous: placed `rotY` = facing + snapYaw = the
    restored in-hand yaw). `placeSave` serializes the stash to
    `o.tilt = {s:[x,y,z], f:[quat]}` when non-identity, and boot restores it
    via `gripRestore` on **both** branches — flat items and `padMountQ` wall
    mounts — so the held angle survives F5 even off the wall. `0`-level a
    held item → the next save drops the `tilt` field entirely.

## 7. Invariants — testable law

1. Door and doorframe are `y0 === 0` forever.
2. A `surf` item is never supported by a `surf:false` item.
3. Re-seat never raises an item (emit/place/move may conform up — re-seat may not).
4. A rider on a desk at `y0 = desktop` stays; a rider with no support drops to `0`.
5. Deleting a host drops its passengers (orphan settle, `oldTop`-capped).
6. `p.bbox` always equals `footB(p.lb, p.x, p.z, p.rotY)` — `placeApply` maintains it.
7. A held item's `0`-key pose has exactly zero pitch/roll (identity × facing yaw).
8. `dropTarget()` never column-scans a host whose footprint doesn't contain the
   sample point (parented recs exempt — their map is queried in world space).

Regression harness: `docs/_place_probe.mjs` (stages the exact cascade — floating
manifest passenger over an extra host's footprint — plus role assertions, the
drop-march scan budget, and the held-rotation snap/tumble/level contract).

---

*Related: `RECENT_CHANGES.md` — "Surface-role law" entry; bug family doc:
`known_issues/runtime/CONSTRUCT_SURFACE_CLIMB_FAMILY.md`.*
