# 📚 Steel City: Mob Sim — Documentation Index

**Purpose**: Central hub for all project documentation — helps coding agents find information fast and efficiently.

**Last Updated**: October 29, 2026
**Project**: Steel City: Mob Sim — Organized Crime Simulation
**Status**: 🔄 ALPHA — Vertical Slice Playable (Unity 6)

---

## 🎯 Quick Navigation

| Category | Documents | Status |
|----------|-----------|--------|
| **Core Design** | 6 docs | ✅ Complete |
| **Systems Design** | 13 docs | ✅ Complete |
| **Data Reference** | 2 docs | ✅ Complete |
| **Source Analysis** | 2 docs | ✅ Complete |
| **Unity Project** | 12 docs | ✅ Complete |
| **VoxelAssetStudio** | 20+ docs | ✅ Complete |
| **Vertical Slice** | 1 doc | ✅ Complete |

---

## 📁 Documentation Categories

### 1. Core Design

**Design Philosophy:**
- **`docs/core/DESIGN_PHILOSOPHY.md`** — Foundational design principles
  - Simple mechanics, complex interactions
  - Data-driven architecture
  - Simulation produces narrative
  - Auto-resolved everything
  - Faithful modernization
  - **Mafia Tycoon, not City Builder** — economy as weapon, not management interface

**Mafia Tycoon Design Principle:**
- **`docs/core/MAFIA_TYCOON_DESIGN_PRINCIPLE.md`** — Guardrail against economic over-engineering
  - The line between mafia tycoon and city builder
  - Information rule: economic data gated behind gang activity
  - Action rule: economic change through crime, not management
  - Quick test for evaluating economic features

**Feature-Driven Architecture Pipeline:**
- **`docs/core/FEATURE_DRIVEN_ARCHITECTURE.md`** — Megaplan methodology for technical foundation
  - Per-feature pipeline: Differentiator → Sim/Data/AI → Render/Perf → Lock-in
  - Running feature tracker (core, nice-to-have, deferred)
  - Performance budget tracker (16ms frame budget)
  - Baseline entity counts from RE + gameplay knowledge

**City State Preservation:**
- **`docs/core/CITY_STATE_PRESERVATION.md`** — Week-to-week city baking & incremental update architecture
  - State categories: financial (week-end batch), physical (immediate), static (frozen)
  - Packed voxel file cache (eliminates redundant .stasset reads)
  - ComputeBuffer persistence across week transitions (no full rebuild)
  - Building swap API for mid-week events (bomb, fire)
  - Event queue design for batch processing at week end
  - Performance projections: 92s → ~20-30s load, 0ms week transitions with no changes

**Performance Patterns:**
- **`docs/COMMISSION_HTML_CONTEXT.md`** — Handoff/context doc: what thecommission.html is, the aesthetic decisions (back-room brick, unified oak floor, pendant, felt-under-table), open design threads (voting UX, hall light, side rooms), working rules
- **`docs/core/VOXEL_INSPECTION_PROTOCOL.md`** — Standard checklist for inspecting voxel assets (integrity, floating pieces, symmetry, layer mix, visual) + the bounded flood-fill rule; tool: `docs/voxel_inspect.py`
- **`docs/core/VOXEL_AUTHORING_STANDARD.md`** — 🔒 LAW: `voxelSize × dims` IS the world — no placement scaling (`vs` mirrors file, `sXZ` banned); reference anchors (Civilian1 0.96m, chibi cast 0.62m), grain standards (item/decor .005), authoring workflow + the Fold/Bend tool (baked voxel skinning for props: live preview, trough/curl/rise/mounds modes, material skip list), Unity `voxelSize` gap, live drift audit of the KIT
- **`docs/core/PERFORMANCE_PATTERNS.md`** — Editor-proven optimization techniques mapped to game systems
  - 20 patterns (#13 brick-occupancy skip is shelved; #14 keyword-gated debug views; #15-#19 added 2026-11-03 from the Room builder: grid-DDA pick, block-merged preview geometry, change-gated previews, headless measuring + CDP profiler, translate-don't-rebuild; #20 added 2026-11-12 from the Construct aim-raycast fix: ray budget = candidates × per-candidate × frequency, prune candidates first — includes a full audit of the engine's existing ray stack): tracked-write maps, partial GPU uploads, delta history, shader-side clip, procedural shader detail, epoch-marked scratch grids, chunked cooperative scans, O(1) region membership, generation counters, slot bookkeeping, view-state signatures, swap-pop + grow-only buffers
  - Each pattern: the real stall it fixed + concrete Steel City reuse (voxel edits, lit-window flips, influence BFS, GPU picking, async guards)
  - Cross-cutting lessons + deliberately-rejected approaches (GPU flood fill, vertex culling)

**Commission Building Pipeline (Voxel Studio -> `thecommission.html`):**
- **`docs/BUILDING_PIPELINE.md`** — editable source -> `bake_building.py` -> runtime bake; period skins, chibi wall recipe, door-bay contract, agent vision toolkit (`_plan.py`, `_shot.mjs --torch`), hall ceiling beam grid (`_hall_ceiling_shift.py`), P.I. front glass (`_office_front_glass.py`), glass contract, compass/axis convention (+x East, +z North)
- **`docs/known_issues/rendering/BAKE_OCC_GRID_DECODE_LAYOUT.md`** — occupancy grid is `(x*H+y)*D+z`, MSB-first; copy the runtime `solid()` decoder, never write a new one
- **`docs/known_issues/rendering/BUILDING_GLASS_OPAQUE_AND_ALPHA_STACK.md`** — any `*glass*` material is transparent in both render paths; opaque faces never cull against glass; door pane = one sheet
- **`docs/known_issues/rendering/KIT_Z_ANCHOR_BACK_EDGE_DRIFT.md`** — KIT z-anchor convention

**Construct Room (first-person authoring/inspection space, `docs/construct.html`):**
- **`docs/CONSTRUCT_DRAFTING.md`** — room law: invisible wall slabs + wall-mounts, aim-ray contract (pruned raycast, hit proxies, noAim), pad pages/remote model, L-key torch rig (auto-exposure: tune = irradiance at 1m, distance-scaled), followers, door console, pad wall-target ownership
- **`docs/CONSTRUCT_PLACEMENT.md`** — placement law: surf-host vs rider roles, `tops` measured surfaces, placeIt/placeSave/persistence keys (`dvm_place` overrides incl. `y`/`tilt`/`mount`, `dvm_extra`, `dvm_lift`, `dvm_del`), boot order (overrides → lifts → mount await → extras → fixpoint cap), grip-vs-pose orientation law
- **`docs/CONSTRUCT_ROOMS.md`** — room bounds: BOUND_WALL slab spec, arch/door portal, annex span, walk rects
- **`docs/CONSTRUCT_MANNEQUIN.md`** — static mannequin (never a follower), outfit pager, `dvm_outfit` persistence
- **`docs/CONSTRUCT_PROBES.md`** — 🔒 headless probe/shot contract: `--eval` is post-capture (scene changes go in `--pre`), `__cam` is async (pin-then-poll `__camera.position`), sparse headless rAF, eval raycasts need fresh `matrixWorld`, assert laws not values, probe-hook API traps, async boot order — read before adding probe/shot sections
- Probe suite: `docs/_place_probe.mjs` (ALL-PASS gate — placement/pad/lift/torch/follower regressions incl. page-error collector), `docs/_shot.mjs` (screenshots: `--cam/--look/--pre/--eval/--torch/--full`)

**City Layout Pipeline:**
- **`docs/core/CITY_LAYOUT_PIPELINE.md`** — Design tool to Unity implementation pipeline
  - `city_editor.html` design tool (COMPLETE): 3-phase pipeline — Macro → Granular (zones+alleys) → Buildings
  - Phase 1: Gangsters 32×32 macro map (embedded replica1_data.js, macro tile painter with undo)
  - Phase 2: Distance-field zones, alley system (25% per commercial/core, 3-lane debris|path|debris), elevated rail line at seed-determined railCol (avoids EC), live color picker (41 materials), LOD system, compute/render split for performance
  - Phase 3: Building footprints (3×3 per block), emoji overlays (civic, municipal, gang HQs, terminal, docks), train animation (north → station → south loop)
  - JSON v3 export with railLine data (railCol, direction, trainRunsPerWeek)
  - Unity pending tasks: CityLayout variable seams, VoxelTerrainBuilder materials, VoxelWaypointScanner, dynamic cover
  - 1920s urban planning research basis (street hierarchy, trolley lines, alley systems)
  - Material IDs: MAT_ALLEY(133), MAT_TROLLEY_TRACK(135, proposed), MAT_COVER_CRATE(131), MAT_COVER_CAR(132)
  - **Canonical block dimensions for voxel assets**: slot = 64×64v, block = 192×192v (3×3 slots + sidewalks = 11.6m tile; terrain chunk = 322×2×322 incl. half-roads), height free-form, full-block mega-buildings (tenement_block_0) carry own courtyard; asset/generator contract for the pending city-generation pipeline

**Source Game Analysis:**
- **`docs/core/SOURCE_GAME_ANALYSIS.md`** — Analysis of Gangsters: Organized Crime
  - .xtx file encoding (4-byte XOR key)
  - Decoded data tables summary
  - Original game architecture observations
  - What to preserve, what to polish

**Differentiation from Original:**
- **`docs/core/DIFFERENTIATION_FROM_ORIGINAL.md`** — Central reference for how Steel City departs from, polishes, and extends the 1998 original
  - Rendering & visual style (2D sprites → 3D voxel raymarch)
  - City generation (static → procedural)
  - Simulation transparency (opaque → visible state)
  - System interconnection (isolated → cascading consequences)
  - Intelligence & fog of war (see everything → territory-based)
  - Police reform (monolithic → individual beat officers)
  - Mafia tycoon principle (economy as weapon, not management)
  - Combat differentiations (environment, INT as tactical AI, morale, physical projectiles, cover, vehicle combat, police escalation)
  - Technical architecture (Unity 6, GPU compute, spatial hash)
  - What we preserve vs what we don't do

**Extracted Game Data:**
- **`docs/core/GANGSTERS_GAME_DATA.md`** — Comprehensive data extraction from 28 decrypted .xtx files
  - Constants: city population (2000 civilians, 400 police, 100 FBI), fear/hostility/squeal tables, bribe prices, FBI suspicion formula, loyalty, recruit tests
  - Economics: All 171 legal business types across 8 groups with full economic data
  - Illegal Economics: All 14 illegal business types with goods flow data
  - Export Ratio: Diminishing returns pricing (Counterfeit $1000, Stolen $200, Liquor $100 per case)
  - Crime: All order types with time cost, suspicion, sentence, investigation, risk values
  - Damage Table: 8 weapons × 7 ranges × 4 damage states
  - Hit Table: 9 weapons × 8 range bands with hit probability formula
  - Hoods: 40 predefined hoods with full stat blocks
  - Character Generation: Hood type generation with skill weightings (includes known skill order bug)
  - Cart: 16 combat attack types with animation result data
  - Business Suspicion: Front suitability for all 15 illegal business types (2=ideal front, 0=poor front)
  - Design implications for Steel City

**Economy & Goods Design:**
- **`docs/core/ECONOMY_DESIGN.md`** — Economy design informed by decrypted game data
  - Three goods types (Counterfeit, Stolen, Liquor) with production/supply chains
  - Warehouse mechanics (12 fixed, never bankrupt, 300+15 case capacity, FBI raid target)
  - Export system (two export points: Docks + Railroad Terminal, diminishing returns)
  - Counterfeit laundering cycle (press → legal businesses → warehouse → export)
  - Business front suitability system (2=ideal cover, 0=poor cover)
  - Illegal business economy (14 types, diminishing returns, profit groups)
  - FBI suspicion system (income threshold $5000, accountant skill reducer)
  - Bribe economy (power-scaled costs)
  - Steel City adaptations: what to preserve, improve, simplify

**Reverse Engineering Findings:**
- **`docs/core/REVERSE_ENGINEERING_FINDINGS.md`** — Ghidra binary analysis of gangsters.exe (18 sections, 2400+ lines)
  - Game timing system (12000-tick weekly budget, 500 ticks/hour)
  - Order type system (dual enum: player orders vs. AI goals)
  - Order setup dispatcher (`FUN_005b3440` — 30+ order types mapped)
  - NotEnough error system (time, cars, bombs, guns, money)
  - **Vehicle-vs-walk decision SOLVED** (bit 15 flag: walk=12000 ticks, drive=32 ticks)
  - Movement state machine (4 states: Init → Pathfinding → Walking → Arrived)
  - Per-tick entity simulation (`FUN_005d2740` — street crossing, wandering)
  - Gang order dispatch with priority calculation (`FUN_0049a530`)
  - Waypoint pathfinding system with countdown timer
  - Block size: 0x60 (96) pixels
  - Engine core deep dive: time budget command queue, pathfinding, street crossing
  - Thunk caller trace analysis (walk/drive dispatch architecture)
  - Vehicle state machine (`0x38000000` field: 3-bit lifecycle)
  - Portrait generation system (5-layer compositor, seed-based)
  - **Section 18: Combat & Pathfinding Deep Dive** — SIM_TICK orchestrator internals (5 queues, 13 cases), 4 combat variants (ranged/melee/vehicle/arrest), waypoint following (3-state), street crossing with traffic lights, AI state machine (8 states with probabilities), entity structure field map, arrest/kidnap message system

**Vehicle RE Reference:**
- **`docs/core/VEHICLE_RE_REFERENCE.md`** — Consolidated vehicle reverse-engineering data (single-stop reference)
  - All 9 Ghidra output files catalogued (walk/drive decision, state setters, flags, traffic, ped interaction)
  - Entity types (tram/train/truck/car with subtypes), key functions table (24 functions)
  - Vehicle flags & bitfields (0x8000, 0x80000, 0x38000000 with setter mapping)
  - Walk vs drive decision logic (distance threshold 0x40, 375× speed differential)
  - SIM_TICK driving cases (4/8/10) with 5-substate advanced driving machine
  - Traffic system (static road flags, street crossing, blocked crossing, vehicle reroute)
  - Pedestrian-vehicle interaction (entity awareness, area scan, post-tick processing)
  - Global state structure offsets, entity structure field map (30+ fields)
  - Time budget system, vehicle strings, vtable architecture, animation system
  - Implementation notes (preserve/modernize/add), re-running Ghidra scripts guide

**Engine Integration Plan:**
- **`docs/core/ENGINE_INTEGRATION_PLAN.md`** — Maps reverse-engineered systems to Steel City implementation
  - 4 core reusable systems: SIM_TICK orchestrator, pathfinding/waypoints, vehicle system, NPC collision/traffic
  - **Vehicle system deep dive**: SIM_TICK driving cases (4/8/10), 5-substate driving AI, vehicle variety table, visual model plans (turning wheels, faction colors)
  - **Section 4A: Dynamic Car Chases & Vehicle Combat Vision** — emergent road encounters, fear/hostility/intelligence trigger system, car chase state machine, 6 emergent gameplay scenarios, code reuse analysis (11 existing systems → 4 new components)
  - C# class designs for each system (SimulationManager, VehiclePhysicsSystem, CarChaseSystem, RoadEncounterDetector, etc.)
  - 5-phase implementation plan with momentum milestones
  - Entity component mapping (original offsets → Unity components)
  - Global state mapping (DAT_007c0024 → SimulationContext)
  - Architecture diagram
  - 8 key design principles from the binary

**Ghidra Scripting Guide:**
- **`docs/core/GHIDRA_SCRIPTING_GUIDE.md`** — Standardized methodology for writing Ghidra Java scripts
  - Script skeleton + key GhidraScript variables
  - Decompilation patterns (timeout guidelines, thunk handling)
  - Caller tracing (including vtable zero-reference workaround)
  - String search (case sensitivity, reference tracing)
  - Binary pattern scanning (x86 instruction patterns for indirect calls, CMP, AND/TEST)
  - Vtable table resolution (scanning .rdata for function pointer arrays)
  - Global state access (DAT_007c0024 offset map)
  - Output file conventions + existing script inventory (23 scripts)
  - Key addresses quick reference (functions, globals, entity types, memory layout)
  - Common pitfalls (signed bytes, thunk resolution, SIB bytes, little-endian)
  - Workflow for adding new scripts

**Steel Tide Porting Manifest:**
- **`docs/core/STEEL_TIDE_PORTING_MANIFEST.md`** — Cross-project bridge: which Steel City systems port to Steel Tide and what they deprecate
  - Lineage: SteelTide was the voxel lab (.stasset, VoxelAssetStudio, AMS); Steel City is the forge where infra-grade versions shipped
  - Port catalog: collision world, volume-aware locomotion, projectiles, destruction+rubble, sector raymarch renderer, weapon mount/IK, instanced characters, build hardening, debug workflow
  - Deprecation list (Steel Tide side) + what stays unique (Geoscape, AMS, structural collapse, FPS cam) + suggested port order

**Headless Compile (agent workflow):**
- **`docs/core/HEADLESS_UNITY_COMPILE.md`** — Compile all of Assembly-CSharp without launching Unity
  - Bundled `DotNetSdkRoslyn/csc.dll` + NetCoreRuntime + UnityEngine module refs + `Library/ScriptAssemblies` package DLLs
  - ~5–10 s check-compile loop for runtime code; same trick as `Tools/dda_selftest/run.sh`
  - Gotchas: quoted paths, `-nostdlib` BCL refs, excluding Assembly-CSharp/CodeGen self-refs, editor-only code out of scope

**Live Editor Pipeline (in-game tuning):**
- **`docs/core/LIVE_EDITOR_PIPELINE.md`** — Tune mechanics while playing, lock them into source via staged promotion
  - Three layers: LIVE sliders → WORKSHOP pending baseline → AUTHORED factory literals
  - Provenance colors (blue/orange/green), click-to-select, promote writes the .cs literal + recompiles in-session
  - Adoption contract for new systems + candidate applications (combat, economy, police, order timing)

**UI Development Pitfalls:**
- **`docs/core/UI_DEVELOPMENT_PITFALLS.md`** — Traps when modifying the Unity UI layer (IMGUI + uGUI)
  - Runtime-created components invisible at edit time; serialized defaults vs inspector overrides; enum serialization
  - `FindFirstObjectByType` cost rules — pitfall #7 (per-frame Update finds) + #12 (OnGUI fires multiple events/frame → finds inside `Draw*Tab()` multiply into a sustained FPS cap)
  - `GetOrCreate` in tab code spawns permanently-running singletons — keep idle Updates cheap

**Business Taxonomy → Asset Generation:**
- **`docs/core/BUSINESS_TAXONOMY_ASSET_GENERATION.md`** — Cross-layer contract pinning the generator roadmap to RE business data
  - 8 business groups → asset classes (commercial slots, industrial, residential, warehouses, charity, municipal, interactive tenements)
  - **BRef discovery**: the original's own archetype column — 171 types collapse to 7 building visuals (BRef=1 storefront covers 101 types, BRef=4 factory covers all 33 industrials)
  - NP (Number Present) priority ranking: tenements + residential ≈ 80% of city surface; storefront archetype next
  - Slot semantics: center slot = illegal/concealment (RE Size=0), perimeter = legal fronts, full-block = Group 7 tenements
  - Generator coverage map + NP-driven roadmap (tenement → storefront → residential → factory → venue → signatures)
  - BREF_MAP type→archetype resolution + pipeline tie-in (Phase 2 zoning → Phase 3 seeding → city_template → generators)

**Zoning Design:**
- **`docs/core/ZONING_DESIGN.md`** — Hub-and-spoke zoning with weighted influence zones
  - Economic Core (EC) at center, Industrial on seed-determined side
  - Rail line: seed-determined N-S column, cuts through any zones (not locked to industrial)
  - Railroad Terminal: municipal building placed ON rail line (export destination)
  - Docks: industrial business in industrial zone (export point + income + recruitment)
  - 14 civic/municipal buildings from Economics.xtx Group 6
  - Weighted influence model with configurable falloff (linear, gaussian, exponential)
  - Export JSON format with zone metadata for Unity consumption

**Keywords**: design, philosophy, principles, source, analysis, xtx, decoding, ghidra, reverse engineering, binary, decompilation, orders, vehicles, timing, combat, pathfinding, sim_tick, traffic, integration, engine, architecture, scripting, vtable, pattern scan, city layout, seam types, alley, main street, trolley, dead-end, waypoint scanner, material ids, city editor, game data, constants, economics, export, counterfeit, liquor, stolen goods, warehouse, docks, railroad terminal, business fronts, suspicion, FBI, bribes, fear, hostility, squeal, zoning, rail line, industrial, commercial, residential, performance, optimization, GPU instancing, flood fill, epoch marks, dirty tracking, compute buffer, partial upload, business taxonomy, bref, building reference, asset archetypes, storefront, factory, tenement, number present, city capacity, slot semantics, illegal center, generator roadmap, imgui, ongui, ui pitfalls, findfirstobjectbytype, event multiplier

---

### 2. Systems Design

**Systems Overview:**
- **`docs/systems/SYSTEMS_OVERVIEW.md`** — All systems at a glance
  - System interaction map
  - Core gameplay loop
  - System priority for prototyping

**Character System:**
- **`docs/systems/CHARACTER_SYSTEM.md`** — Hood generation and progression
  - Weighted archetypes (from original's 18 types)
  - Skills (10, 6-bit range 0-63)
  - Intelligence (8-bit, 0-255) as tactical AI stat
  - NPC personality: Fear, Hostility, Squeal (citizen metrics)
  - Gang member personality: Loyalty, relationships

**Animation System (canonical):**
- **`docs/systems/ANIMATION_SYSTEM.md`** — End-to-end animation pipeline truth: HTML authoring → `.character.json`/`<name>.json` → Unity
  - Authoring surface (`character_animator.html`): states incl. pseudo-state 5.1 (deep-crouch endpoint) + authored reload 13/14, diffed `animParams` export, carriedFields
  - Full `animParams` schema (walkKeyframes, crouching/`crouchDeep`, aiming, reload/reloadCrouch, sitting, vision…) + C# default-fill rules
  - Two blend mechanisms: timed dual-eval transitions vs `crouchDepth` axis; the stand→shallow gap + planned unified `duck` axis
  - GPU/CPU/JS parity contract, `_InstanceAnimData`/`_InstanceIKData` layout, silhouette measurement → `h(d)` cover contract
  - Crouch-walk state contract (born from the duck-axis work)

**Character Spawning & Instancing:**
- **`docs/systems/CHARACTER_SPAWNING_SYSTEM.md`** — How character entities are spawned, instanced, and rendered
  - Single model (Civilian1.json) shared across all entities via GPU instancing
  - Four spawner scripts: HoodSpawner (debug), CharacterRig (GPU test), AnimationTestSpawner (CPU test), StressTestSpawner (perf test)
  - Component stack: VoxelCharacter + CharacterAnimation + ClothingSystem + PedestrianLookAround
  - GPU instancing pipeline: sharedVoxelBuffer (one per model), posedVoxelBuffer (per visible instance)
  - Consolidated .character.json format (voxels + groups + regions + pivots + animParams in one file)
  - Voxel scale standards: building 0.05m (Unity-forced), character 0.01m, item/decor 0.005m
  - How to set up character entities (editor, code, spawner)
  - Model upscaling tool for raymarch artifact fixes

**Extortion & Territory:**
- **`docs/systems/EXTORTION_TERRITORY.md`** — Core gameplay loop
  - Extort → Refusal → Escalation → Consequence chain
  - Territory strength (0-100 per block)
  - Block information tiers (Blind → Aware → Informed → Connected → Networked)
  - Market share diminishing returns

**Intelligence System:**
- **`docs/systems/INTELLIGENCE_TERRITORY.md`** — Territory-based fog of war
  - What you own is what you know
  - Squealer identification pipeline
  - Business radar (refined from original)
  - Friendly NPCs as informants

**Perception & Awareness:**
- **`docs/systems/PERCEPTION_AWARENESS.md`** — City-wide detection architecture (SPEC + partial implementation)
  - Cone = awareness, exposure probe = geometry — noticed ≠ shootable
  - **Hearing channel shipped**: `SfxWaves.Report`/`Heard` — radius broadcast on every real shot; `CombatController.OnSfxHeard` self-filters (in `AmplitudeAt` earshot, shooter is threat/watch target) → `OnShotHeard` belief snap = intel, not a sighting
  - Still spec: per-actor awareness tables, recognition tiers, citizen turn-to-sound/report/flee reactions
  - Combat hand-off + search resolution path

**Corruption & Police:**
- **`docs/systems/CORRUPTION_POLICE.md`** — Beat cops and bribery
  - Geographic corruption (per-beat, not global)
  - Simple bribe mechanic: pay weekly, they suppress heat
  - Internal Affairs as natural ceiling
  - Rival gang corruption competition

**Combat System:**
- **`docs/systems/COMBAT_AUTOBATTLE.md`** — Auto-resolved encounters (📐 core live — continuous real-time fixed-step sim, not round-based)
  - Intelligence as tactical decision quality
  - Skills determine effectiveness
  - Environment factors (cover, crowds, time of day)
  - No player micromanagement — hoods use their stats
- **`docs/systems/PROJECTILE_SYSTEM.md`** — Physical projectiles + voxel raycasts (v1 implemented + playtested)
  - Muzzle → bore axis → seeded cone (skill 1–10 × base cone) → swept flight → nearest hit with exact volume / voxel / material
  - `VoxelCollisionWorld.Raycast`: pure 3D DDA over the terrain grid + shared-array building volumes (sector and per-building paths)
  - ShotReport payload for glass puncture / cover / damage; Combat tab FIRE controls; offline self-test `Tools/dda_selftest/run.sh`
- **`docs/systems/COMBAT_COVER_STATE.md`** — Autonomous combat phase 1: Combat state → verified cover seek (vehicles are solid + promote-on-hit damageable)
  - `VoxelVehicle` registers yawed collision volumes; `CoverFinder` validates cover by real LOS raycast from the threat
  - `VoxelDamageSystem.EnsureWritable` promotes `veh_*` targets into private-buffer singleton groups (bullet holes, windshield shatter)
  - `CombatController` on Vinny: EnterCombat → SeekingCover (steer, slide) → InCover (Crouching pose + ArmAimSolver)
- **`docs/systems/EXPOSURE_ENGAGEMENT.md`** — Combat phase 2 spec: visible-voxel aim target + exposure FIRE gate (the crossfire model)
  - `TryGetVisibleVoxels(eye, target)` — ~40 posed-silhouette samples, world-unobstructed rays → centroid = IK target, visibleCount>0 = FIRE
  - Emergent beats: duck-in fades firing, tucked = crouch-idle + `lastSeenTarget`, pop-up = authored override + mutual exposure window, 6-shot cylinder → duck-reload
  - Caveats: characters aren't in the collision world (no self-occlusion); AI fire loop is the first one ever; deferred triggers listed
- **`docs/systems/ENGAGEMENT_BEATS.md`** — Combat phase 3 (✅ implemented): authored engagement rhythm over the exposure gates — opportunity fire during seek, `Settle` seam primitive, partial `TopUp`, triangulated `Rise` (eye AND muzzle clear), "stand and deliver" `Engaged`, `Duck` + seam loop
  - Beats sequence intent; gates still decide what's possible — `wantAim` gains a per-beat authority term
- **`docs/systems/AIM_RIG.md`** — SPEC + phases 1–3 implemented & playtest-validated: one focal point drives torso, head, arm(s) and weapon so the muzzle sits near the eye line
- **`docs/systems/MOVEMENT.md`** — Locomotion model as-built: `StepToward`/`StepRouted` mover (per-frame integration, swept collision, stuck-guard nudges), static universal `moveSpeed`, foot-locked gait (`horSpeed→walkSpeed→gaitTime`), HUD tuning surface; includes the rolled-back ramp experiment notes
- **`docs/systems/COMBAT_PARAMETER_MATRIX.html`** — Interactive relationship graph of the whole combat system: every HUD dial, broadcast channel, per-fighter blackboard state, decision engine and body output, with labeled edges showing which feeds which; includes the menace/IFF chain and closed firefight loop views + stimulus→response and coupling tables
  - Measured eye/shoulder/muzzle offsets (muzzle ~12.5 cm lateral of the eye), solve order, GPU/CPU/JS channel gaps (head override CPU-only, one arm channel pair), 5 phases with trace gates; two-handed rifle/shotgun path
  - Runtime safety net already shipped: `muzzleShootGate` (shootable = eye ∧ muzzle visible) — see `docs/known_issues/runtime/EYE_SEES_MUZZLE_CANT_SHOOTABLE_GAP.md`
  - Deferred: rise-retry cadence + interruption policy (wait Tan mobility), lookScan slot, branch table, per-weapon cylinders
- **`docs/systems/COMBAT_PERFORMANCE_REVIEW.md`** — End-to-end combat performance review (Oct 29): what's already optimal, what was costing (redundant pose eval + per-frame garbage), shipped behavior-identical fixes with offline proof (`Tools/anim_selftest/run.sh`: 156k bit-exact checks, 2.6–3.6× probe pose; `Tools/cover_selftest/run.sh`: bit-exact wall-column cache, 3×+ warm scan), group-fight scaling map, and a ranked backlog of behavior-affecting items awaiting decisions (rescan gating, probe cadence, timing consistency)
- **`docs/systems/PERFORMANCE_PLAN_HUD_AND_JOBS.md`** — PLAN: (1) the IMGUI debug HUD is ~54 % of a profiled frame (`CoverMetricsPanel` 7.6 ms of native text regeneration) — bake/retain fix + event discipline + budget; (2) job-system plan for group-fight scale — blittable-data order, ranked job candidates, SimClock-tick scheduling, determinism rules, phase gates. Wall-cover math explicitly untouched
- **`docs/systems/COVER_HEIGHTFIELD.md`** — SPEC: measured-body cover rebuild — silhouette-top `h(d)` instead of eye constants
  - `ColumnTopY` ground probe (standing on voxels is additive), `wallIdxOf` cell bookkeeping, Step layer (step-up nav), digit-atlas height blit into the field overlay
  - Canonical scale: Vinny = 0.62m (62 vox @ 0.01); world voxels = 0.05m

**Debug & Test Harness:**
- **`docs/systems/TEST_WEEK.md`** — the open-week debug order (formerly `target_practice`): holds the week in `Dwelling` state so feature testbeds are live
  - Testbed registry: `shooting_range` (firing lanes), `cover_arena` (symmetric duel, in front of tenement door), `debris_test_lot` (blast testing) — routed by authored attachment points
  - `testWeekDwells`/`testWeekSkipWalk` toggles; `Enter` releases the week
- **`docs/systems/POSSESS_BODY_DEBUGGING.md`** — the possessed body IS the probe: wedge detection (all move lanes refused + input held 0.75s) → teleport + one structured `[Possess] UNSTUCK` emit
  - `ExplainSquare`/`ColumnFreeDetail` iterate the identical `SquareDirs`/`ColumnFree` law — the diagnostic can't drift from the verdict; failed samples name the owning volume, cell, and world position
  - Field opinion per emit (`walk`/`reach`/`OFF-WINDOW`) splits "map lied" from "player-steered pocket"; roadmap: combat-mover snag emits, route-commit verification, `snag.jsonl`, per-character event rings, health/hit emits

**Weapon & Item Models:**
- **`docs/systems/WEAPON_ITEM_MODEL_STANDARD.md`** — Voxel modeling standards for weapons, items, and props
  - Voxel scale: 0.005m/voxel (2× density vs upscaled characters; per-file `voxelSize` field)
  - Weapon classes: revolver (base Pistol), M1911A1 (Twin Pistols), Tommy Gun, rifle, shotgun, melee
  - Orientation conventions (barrel +X, grip +Y)
  - Default dims [48, 26, 10]; `Tools/gen_sw_model10.py` parametric generator
  - Material palette for weapons (gunmetal, wood, brass)
  - Transform-based hand attachment (supersedes buffer compositing)
  - Voxel editor "Item / Decor" asset type setup

**Weapon Attachment & Grip Points:**
- **`docs/systems/WEAPON_ATTACHMENT_SYSTEM.md`** — Voxel-painted attachment point system for weapon-to-hand alignment
  - Painted marker voxels define named points (grip_right, muzzle, cheek_weld, etc.)
  - Data-driven: stored as `attachmentPoints` in weapon and character JSON
  - Runtime alignment: weapon grip point → character posed hand position via FK
  - One-handed (pistol) and two-handed (rifle) alignment modes
  - Rotation derived from muzzle→grip vector (forward) and grip_left→grip_right vector (up)
  - Grip pose integration with existing AIM_WEAPON_PRESETS system
  - Editor painting tool plan + Unity implementation phases

**Character Asset Lifecycle & Pose Authority:**
- **`docs/systems/CHARACTER_ASSET_LIFECYCLE.md`** — Atomic character-asset infrastructure
  - `CharacterAssets` registry: single parse, shared truth for all consumers
  - `VoxelCharacter.WhenReady`: explicit init ordering (replaces coroutine polling)
  - `CharacterAnimation.RequestPose`: priority pose-override channel (no state stomping)
  - Single defaults table: GPU pose upload emitted from the same `ParamsData` as CPU weld
  - Gotchas catalog G1–G8 (divergent parses, race windows, contested state, stale handles)

**Crime & Squeal:**
- **`docs/systems/CRIME_SQUEAL.md`** — Crime escalation and consequences
  - Crime table with suspicion/sentence/investigation values
  - NPC squeal rolls trigger investigations
  - Escalation ladder (extort → intimidate → assault → torch → bomb)
  - Investigation visibility and leads decay
  - **Fear Trap**: High fear increases squealing (terrified people talk more)
  - **Information tiers**: Lawyer-gated squealer identification, conditional reports
  - **Legal system chain**: Post-arrest pipeline (Lawyer, Judge/DA bribes, witness/juror intimidation)

**Playtesting Insights:**
- **`docs/systems/PLAYTESTING_INSIGHTS.md`** — Insights from original game manual study + live playtesting
  - Fear/Hostility/Squeal three-axis model with counterintuitive fear-squeal relationship
  - Extortion mechanics (intimidation skill only, office proximity, manpower, service contract model)
  - Information asymmetry design (Lawyer-gated, indirect detection, deduction game)
  - Territory strategy ("baby and scare" your territory, attack rival, donate in neutral)
  - Legal system, illegal business front-matching, diplomacy levels, snitches
  - Open questions for further playtesting

**3D City Rendering:**
- **`docs/systems/3D_CITY_RENDERING.md`** — Working Week visualization
  - Two-phase visual split (2D planning + 3D execution)
  - Simulation as playback layer (decoupled from rendering)
  - Entity budget (~3000-4000, bounded)
  - Event stream format
  - Camera system (free orbit, follow mode)
  - Performance budget and comparison to SteelTide

**Path Debug Rendering:**
- **`docs/systems/PATH_DEBUG_RENDERING.md`** — Instanced box-beam debug path rendering via CommandBuffer
  - Replaces LineRenderer (invisible under voxel RawImage overlay)
  - `CommandBuffer.DrawMeshInstanced` into voxel render texture
  - Per-type batching (Pedestrian/Car/Trolley) with single color per draw call
  - Camera hookup gotcha: bridge must pass camera explicitly (Camera.main fails in URP)
  - Fallback behavior when no VoxelRenderBridge present
  - Diagnostic logging pipeline for troubleshooting

**Voxel Glass & Transparency:**
- **`docs/systems/VOXEL_GLASS_TRANSPARENCY.md`** — Per-cell alpha blending model, authoring & tuning guide
  - Accumulation math: transmission = (1−a)^cells; **settled convention: panes are 1 voxel thick + air bore** (baked into all generators)
  - Grazing-angle banding (inherent); tune face-on; emissive material list (113/115–117/124) + no-light-spill caveat
  - Inspector knobs (alpha/specular/maxLayers) + `:WALL_T` vs `[:1]` authoring + hollow-interior lit rooms
  - Windows↔projectiles design boundary: visual vs ballistic transparency → resolved by the shatter spec below
- **`docs/systems/GLASS_SHATTER_MECHANIC.md`** — Glass destruction prototype proposal (no physics)
  - Seeded bullet-hole model: impact + ring-falloff removal, cracked-halo material, gid pane-unit cascade
  - Removed voxels = shard particle spawn list (voxel→particle 1:1); damage type → break radius table
  - P0–P3 phased plan: puncture → dressing → pane semantics → sim hooks (noise/LOS/persistence)
  - **Unified cellular debris** (implemented): the voxel IS the particle — in-grid ballistic rain (`StepFalling`), world-space flying-voxel transport (`StepFlyer` point queries, no swept rays), and cross-volume handoff that flips a pristine neighbor into damaged state on first arrival; per-cell emission stride-samples at the `maxFlyingCells` budget; offline self-test [13]–[18]
- **`docs/systems/PROCEDURAL_AUDIO.md`** — In-memory `AudioClip` synthesis (no audio assets)
  - Recipe: noise attack + inharmonic decaying partials + noise tail; `exp(-kt)` envelope does the heavy lifting
  - Bucket mapping (removed-count → tink/crack/crash); `PlayClipAtPoint` requires an active `AudioListener`
  - Generalizable sound palette (gunshot/ricochet/footstep/engine) + `SynthRecipe` struct → HTML editor path
  - **Editor built**: `VoxelAssetStudio/audio_studio.html` — layer-based synth (attack/partials/noiseTail/sweep), ADSR, presets, spectrum, 🎲 seeded variants, `.stsound` JSON export
- **`docs/systems/SFX_SOUND_CATALOG.md`** — Living design log: per-sound intent, recipe anatomy, tuning history, variant families (every sound gets an entry; recipes hold numbers, this holds the why)
- **`docs/systems/SFX_PIPELINE.md`** — Runtime audio architecture handoff (delegate SFX work here)
  - Event flow: `ShotResolved` family — ProjectileSystem owns gunshot, SurfaceImpactAudio owns impact/ricochet, VoxelDamageSystem owns glass
  - `sounds/Impacts/` one-folder-two-pools split by filename; `LiveTesting/` exclusive test pool; per-file `.cull.json` sidecars (variant culls + gain/volume trims)
  - Runtime Variant-Lab modulation (seeded children per hit), physics gate (incidence ≥85° + ≤40m → ricochet), per-family mute toggles, SfxWaves two-layer split (`Report` = semantic `Heard` → AI hearing on every real report; `Emit` = visual debug shell only)

**Voxel Engine Gotchas:**
- **`docs/systems/VOXEL_ENGINE_GOTCHAS.md`** — Non-obvious bugs and traps in the voxel rendering/collision/terrain system
  - ProbeGround flat-array index aliasing (vy out of bounds → false ground hit at Y=66)
  - DebrisScatter log spam (900+ lines per build from per-item logging in batch loops)
  - Empty plot detection (partial vs fully vacant block — per-building vs block-level predicate)
  - Shader animation "Approach A" (output-only offset invisible — must use inverse-transform sampling in DDA)
  - Missing CharacterAnimation component on spawned hood (animState stays 0, pipeline fed zeros)
  - Coordinate-space mismatch (region centroid +0.5 off — index vs cell-center space)
  - Stripped `handedness` marker (gun backwards at idle — IK solver masked the bad static roll)
  - Key voxel engine constants table (terrain thickness, voxel sizes, index formula, animation groups)

**Voxel Coordinate Spaces (normative):**
- **`docs/systems/VOXEL_COORDINATE_SPACES.md`** — Canonical voxel-space conventions for all JSON ↔ animator ↔ Unity positions
  - Index space is the interchange space ("voxel index = rendered center"); cell-center space is the trap
  - Centroids are bbox midpoints `(min+max)/2` — even spans → `.5` (seam), odd → `.0` (voxel)
  - Per-consumer conversion table + new-code rules + region-feature checklist

**Refactoring Roadmap:**
- **`docs/systems/REFACTORING_ROADMAP.md`** — Future code extraction plan to keep files manageable
  - Current file size assessment (VoxelChunkManager ~2K, CityMap3D ~1.6K, GameUIController ~1.4K)
  - Extraction plan: CityMapCamera, BuildingLoader, SectorBakery, ChunkBufferManager, OrderPanelController
  - Trigger conditions for when to extract (not premature)
  - Anti-patterns to avoid (line count alone, during creative sessions, deep dependency chains)

**River & Bridge Tiles (M2):**
- **`docs/systems/RIVER_AND_BRIDGE_TILES.md`** — River + bridge spec for the 32×32 city
  - "Smart foundation": depth only at the river channel — carved water tiles + quay walls, land stays a 2-voxel pancake
  - Tile ownership: chunks own block + half-roads; water–water seams carve to continuous channel, water–land seams stay riverside roads
  - Neighbor-mask recipe system (4 bits → straight/corner/cap/interior variants)
  - New material `MAT_WATER=137` (needs `MaterialCount`/`MaxMaterials` ≥138)
  - Prototype: `Tools/generate_river_tile.py` → `JSON Models In Progress/river_straight.json` (116×24×116 @ 0.1, 1.4m channel)
  - Status: straight-river 10×10 playtested ✓; corner recipe + full replica run pending

**Road Lanes & Traffic:**
- **`docs/systems/ROAD_LANES_AND_TRAFFIC.md`** — Lane/traffic design + F10 two-car test plan
  - `roadWidth` = `4.5f` (`[SerializeField]`, uniform across all seams — per-seam widths pending) — two ~2.25 m lanes around the ~0.7 m-wide `vehicle_490_touring`
  - Cobble stripes sit at each corridor-half’s center (the quarter positions, ±`roadWidth`/4) — each tile paints its own half’s stripe so the pair across a seam reads as the dual-traffic divider; lane offset ±`roadWidth`/4
  - "Slot cars" Phase A: fixed lane offset, intersection reservation, car following; Phase B: turn arcs, Dijkstra routing, trolley actor
  - Main street = through-cell 4-lane spine with trolley track pair ±0.35 m + ±0.6 m rail buffer (cars may cross, never cruise/park)
  - Open bug: `docs/known_issues/runtime/ROADGRAPH_IGNORES_TERRAIN.md` — RoadGraph links cross open water (step 1 of the plan)
  - Editable mainstreet tiles: `Tools/generate_mainstreet_tile.py` → `mainstreet_ns/ew.json` (116×64×116 @ 0.1)

**Vehicle Voxel Assets:**
- **`docs/systems/VEHICLE_VOXEL_ASSETS.md`** — How vehicles render (static shared-buffer instancing), the three buffer modes, articulation + paint roadmap
  - Multi-instance OOB gotcha fixed via `_SharedRestBuffer` (Pitfall #7; `STATIC_INSTANCED_OOB.md`)
  - Watch item: axis-aligned proxy cube ignores yaw — non-cubic cars can crop at 90° headings (Pitfall #8)
  - Articulation = vehicle `.groups` + a vehicle pose mode in `CharacterPoseCompute.compute` (gid semantics are character-anatomy hardcoded today); doors/wheels for "Vinny uses the car"
  - Paint via per-instance tint (free `.w` in `_InstanceOffsets`) — cheaper than posing; region remap only exists in the compute kernel
  - Planned `vehicle` asset type in `voxel_editor.html` (`VEHICLE_PART_GROUPS`: wheel/door gids, axle/hinge pivots, seat/entry attach points); assets should move to `voxel_vehicles/` (currently `voxel_buildings`)

**City Scale Architecture (32×32):**
- **`docs/systems/CITY_SCALE_ARCHITECTURE.md`** — Scaling the city from the 10×10 test rig to the 32×32 production blueprint
  - Findings: terrain sector overflow (half the roads vanished silently), layout-generator schema drift
  - Sector invariants (≤511 instances, ≤2^24−1 voxels, ≤2^27 elements per sector) — the rules new terrain/seam/building work must respect
  - Measured build timings (10×10 ≈ 1.1 s vs 32×32 ≈ 14 s) and memory budget (~1.83 GB voxel data)
  - Prioritized optimization backlog O1–O9 (loud sector guard, collision-grid regrow, empty-lot variant pool, terrain tile dedupe, sector LOD, …) with evidence + status
  - Milestone plan M0–M4 (32×32 render → profile → river/bridge → zones→buildings → integration)
  - Tooling: `Tools/generate_city_layout.py` (`--activate` / `--restore`), where the Unity/`buildmap_log.txt` logs live

**Instanced Rendering Pitfalls:**
- **`docs/systems/INSTANCED_RENDERING_PITFALLS.md`** — Non-obvious behaviors of the custom raymarch instancing pipeline
  - Why toggling GameObjects in Inspector doesn't hide them (CommandBuffer bypasses Unity culling)
  - activeInHierarchy check fix in RenderInstancedGroup
  - No frustum culling on instanced characters
  - Unregistering vs destroying patterns
  - Baked sectors have same issue (sector.active flag, not GameObject hierarchy)
  - Architecture diagram: standard Unity pipeline vs Steel City voxel pipeline
  - Debugging tips for invisible/stuck/missing characters

**Keywords**: systems, character, spawning, instancing, hoodspawner, characterrig, animationtest, stresstest, clothing, pedestrian, voxelcharacter, characteranimation, clothingsystem, pedestrianlookaround, gpu, sharedbuffer, posedbuffer, consolidated json, upscale, extortion, territory, intelligence, corruption, police, combat, crime, squeal, 3d, rendering, visualization, camera, playtesting, insights, fear, hostility, legal, diplomacy, path, debug, beams, commandbuffer, instanced, voxel, gotchas, pitfalls, collision, probe, terrain, flat-array, aliasing, animation, shader, raymarch, dda, inverse-transform, groupid, stance, characteranimation, refactoring, extraction, modular, file size, citymap, chunkmanager, buildingloader, sectorbakery, activeinhierarchy, drawmeshinstanced, computebuffer, unregister, frustum, weapon, item, prop, decor, revolver, pistol, m1911, tommy gun, rifle, shotgun, voxel editor, asset type, gunmetal, attachment, hand, glass, transparency, alpha, emissive, windows, windshield, lit window, shatter, destruction, bullet hole, cracked halo, shard particles, pane gid, projectile, ballistics, raycast, voxel dda, cone of fire, firing range, collision volumes, shot report, animation system, animparams, crouchdepth, crouchdeep, pose transition, dual-eval, requestpose, duck axis, crouch walk, character animator html

---

### 3. Data Reference

- **`docs/data/GAME_DATA_REFERENCE.md`** — Extracted data from original game (legacy)
  - Constants (population, fear, squeal, bribes, FBI, elections)
  - Character generation archetypes
  - Crime table (all 30+ crimes)
  - Hit/damage tables (9 weapons × 8 ranges)
  - Economics (171 legal businesses, 14 illegal)
  - Suspicion matrix
  - Scenarios (10)
  - Market share decay curve
  - Profit/running cost tables

- **`docs/core/GANGSTERS_GAME_DATA.md`** — Comprehensive decrypted game data (28 .xtx files)
  - See Core Design section above for full description
  - Supersedes GAME_DATA_REFERENCE.md with more complete data from decrypted files

**Keywords**: data, reference, constants, crime, weapons, economics, businesses

---

### 4. The Commission — Deliberation & Verdict Machine

Multi-agent deliberation system living in `docs/` — the boss proposes, the CHAIR tables, the ARCHITECT drafts designs, the INFORMANT gates them for completeness, the table votes, the BUTTON builds only on a unanimous SHIP + explicit boss GO CODE, the CHAIR certifies. Eleven proposals shipped (DVM-002 … DVM-014) as of 2026-10-30.

- **`docs/COMMISSION_PROTOCOL.md`** — THE LAW: bus contract (`window.DVM_FEED`), message kinds, boss semantics (`@SEAT` routes the floor), seat lifecycle, write discipline (read → append ONE → rewrite whole file, strict JSON)
- **`docs/thecommission.html`** — THE DASHBOARD: noir 3D back-room (three.js) where bus state is made visible — lamps = presence (burn down to deadline), amber underglow = floor, neon sign = phase, chair bubbles = latest speech, wall pegboard = proposal lifecycle (TABLED→…→CLOSED); files navigator over `board.files[]`/`staged[]`; honest 2D fallback; SSE push + script-tag poll
- **`docs/deliberation_feed.js`** — THE TABLE: whole-state append-only bus (proposal, phase, turn, seats, messages, verdict, board{rules,agenda,closed,seat_rules,staged,files}, adjourned)
- **`docs/commission_watch.py`** — THE EAR: `python commission_watch.py <SEAT> [timeout]` — stamps `presence_<SEAT>.js` once per arm, polls the bus, exits on turn/boss; dormant mode under `adjourned`
- **`docs/commission_server.py`** — Boss write-path + static host (`:8723`): `/boss`, `/table` (evicts matching `staged[]`), `/adjourn`, `/reconvene`, `/events` (SSE)
- **`docs/drafts/`** — Implement-draft archive, one file per DVM (the INFORMANT's gate works these)
- **`docs/induction_<SEAT>.txt`** — Per-seat induction briefs (ARCHITECT, INFORMANT, BUTTON, AUDITOR)
- **`docs/presence_<SEAT>.js`** — Ephemeral watcher stamps (gitignored — runtime state, not source)
- **`docs/LOCAL_SEAT_OPS.md`** — LOCAL-SEAT OPERATOR REFERENCE: six chairs on one LM Studio `qwen3.5-9b` via `commission_seat.py` hosts — seat_panel cockpit + seats_up/down bats, cold-start/refresh/kill workflows, the state ladder (working vs vacant), job-bound ears + brain-death exit + ORPHAN-EAR flag (C35/C36/C40), per-seat file map
- **`docs/commission_seat.py`** — LOCAL HOST: ear → bounded prompt (induction + seat_state + diary hot window + tail) → model → daemon-law fences (lane override, floor stamp, memory stub, NEED fetch, refusal resilience) → `/post` or `/dm`

**Keywords**: commission, deliberation, agents, DVM, bus, dashboard, three.js, seats

---

## 📋 Document Conventions

- All design docs use Markdown
- System docs follow template: Overview → Original Implementation → Modernization → Data Schema → Interactions
- Data references include source file name from original game
- Status indicators: ✅ Complete | 📐 In Progress | 📝 Planned | ❌ Blocked

---

## 🔗 External References

- **Gangsters Data Codex**: `gangsters_decoded/index.html` — Visual HTML viewer of all decoded game data
- **Decode Scripts**: `scripts/crack_xtx.py`, `scripts/decode_all_xtx.py` — Tools used to decode original game files
- **Codex Generator**: `scripts/generate_codex.py` — Generates the HTML codex from decoded data

---

## 🎮 Unity Project Documentation

All Unity-side documentation lives in `Assets/docs/`. See `Assets/docs/DOCUMENTATION_INDEX.md` for the full index.

### Key Unity Docs
- **`Assets/docs/GAME_DESIGN_SKELETON.md`** — Core game design (mechanics, phases, systems, data schema, dev sequence)
- **`Assets/docs/VOXEL_LIGHTING_AND_SHADOWS.md`** — Raymarch lighting pipeline (hybrid normals, shadow debug, lighting toggles)
- **`Assets/docs/VOXEL_BUILDING_METHODOLOGY.md`** — Voxel building generation pipeline
- **`Assets/docs/MOB_SIM_SCALE_STANDARD.md`** — Scale system (voxel sizes, door sizes, reference objects)
- **`Assets/docs/COORDINATE_SYSTEM.md`** — Positioning & coordinate spaces (MapRoot offset, block grid, character placement, corner vs center)
- **`Assets/docs/PORTING_NOTES.md`** — Python → C# porting gotchas and verification

### Simulation Architecture (Assets/Scripts/Sim/)
- **`FollowCamera.cs`** — Follow camera with spherical coordinate positioning, free-look mode, OnGUI debug HUD, hotkey controls, UI auto-hide, VoxelRenderBridge integration
- **`SimulationManager.cs`** — Pure logic simulation manager (produces SimEvents, no Unity-specific references)
- **`EventPlayer.cs`** — Consumes SimEvents from SimulationManager, drives visual updates
- **`SimEventStream.cs`** — Event stream with SimEvent factory methods
- **`VoxelCharacter.cs`** — Voxel character rendering with WorldCenter property for camera aiming
- **`ClothingSystem.cs`** — Per-instance clothing/outfit system. Uses VoxelChunkManager per-instance remap API (SetInstanceOutfit) to apply unique material remapping per character without breaking GPU instancing. Auto-adds to VoxelCharacter when useInstancing=true
- **`CharacterRig.cs`** — Character animation controller with hotkeys (T/I/W/L/A/C). Controllable flag + ActiveRig static for multi-character hotkey routing. Uses GPU instanced rendering path (VoxelCharacter + CharacterAnimation)
- **`DebugHUDManager.cs`** — In-game debug panel with tabs (Camera, Render, Clothing, Path, Keys). Auto-spawned by `CityMap3D` if absent; toggle with `` ` ``/O, Tab cycles tabs. Keys tab is a live hotkey cheat-sheet (only lists bindings whose handler components exist). Clothing tab has dual selectors: green buttons for character hotkey routing, blue buttons for outfit instance selection
- **`Pathfinder.cs`** — A* pathfinding on WaypointGraph
- **`WaypointGraph.cs`** — Waypoint graph with sidewalk/crosswalk/jaywalk links

### Per-Instance Clothing System
- **`ClothingSystem.cs`** — Per-instance outfit remapping via VoxelChunkManager API
  - Region-based remapping: outfits applied by remapping material IDs within voxel regions (Torso, Arms, Legs, Feet, etc.)
  - Uses `SetInstanceOutfit()` / `GetInstanceOutfit()` — no shared buffer modification
  - Auto-adds to VoxelCharacter when `useInstancing=true` and asset has regionDefs
  - OutfitPresetType enum for quick preset selection
- **`CharacterPoseCompute.compute`** — CSPose kernel applies per-instance material remap via `instanceMaterialRemapBuffer`
- **`VoxelChunkManager.cs`** — `instanceMaterialRemapBuffer` per InstancedGroup, built per-frame from `InstancedCharacter.materialRemap` arrays
- **`CityMap3D.cs`** — Consolidated spawning: `Characters/Civilians/Civilian_01 + Civilian_02` with `ApplyCivilianOutfits()` coroutine
- **`docs/PROCEDURAL_CLOTHING_CONCEPT.html`** — Visual concept document for procedural clothing system

### VoxelAssetStudio Roadmaps
- **`VoxelAssetStudio/IMPROVEMENT_ROADMAP.md`** — V2.0 improvement plan (undo/redo, layers, selection tools)
- **`VoxelAssetStudio/PHASE2_IMPLEMENTATION_PLAN.md`** — Skeleton rigging system plan
- **`VoxelAssetStudio/INTERACTIVE_JOINTS_ROADMAP.md`** — Interactive joint manipulation
- **`VoxelAssetStudio/GENERATOR_STUDIO_PLAN.md`** — Procedural generation as an editor sub-module: classic-script `gen_core.js` + per-archetype generators, param-schema sliders, preview→accept pipeline, lock-spec JSON shared with Python batch; implements the loose→locked→catalog lifecycle from `BUSINESS_TAXONOMY_ASSET_GENERATION.md`
- **`VoxelAssetStudio/city_editor.html`** — City Layout Editor (3-phase pipeline: Macro → Granular → Buildings, see `docs/core/CITY_LAYOUT_PIPELINE.md`)

### Vertical Slice
- **`docs/VERTICAL_SLICE_DESIGN.md`** — End-to-end test design (9 blocks, 2 factions, 5-10 weeks)
