'use strict';
/* construct/03_tables.js — drafting tables: emitTable, piston lift, stasset/block/zone emit, emitRing/emitCore (static street + swappable interior), emitVox, parked cars, blockTrf cruise, mini sync/slice/spin, mountModel + table boot.
   Split from construct.html (was lines 289-772); classic <script defer> siblings share one
   page-wide scope, load order = the old top-down eval order. */

/* ═══ DRAFTING ROOM — the west annex's exhibit layer. MANIFEST.tables is the expansion seam:
   each entry builds one square low table (dark furniture stock + the floor-wire seam lifted to
   the tabletop rim — the same trick the doorway uses) plus its miniature buildings. The table is
   a surf-role PLACED rec, so the measured-surface law hosts items on it natively; each miniature
   writes its own per-column top into the host's tops map (a model's roof and open courtyard read
   as different heights — measured, never authored). ═══ */
const BLDG_VS = .05;                                                    // the in-game voxel — terrain AND buildings (VoxelChunkManager forces .05)
const BLDG_MAT = {                                                       // mob_materials.py — MUST match StAssetReader.cs
  10: [.80,.80,.80],                                                     // vehicle trim (MAT_LIB #cccccc) — stamped cars ride this palette too
  100: [.58,.26,.20], 101: [.48,.42,.34], 102: [.58,.58,.54], 103: [.82,.80,.74], 104: [.18,.18,.20], 105: [.42,.38,.34],
  106: [.30,.18,.10], 107: [.60,.42,.25], 108: [.42,.36,.26], 109: [.28,.24,.22], 110: [.42,.40,.36], 111: [.90,.88,.82],
  112: [.45,.55,.65], 113: [.45,.55,.65], 114: [.55,.65,.70], 115: [.95,.15,.15], 116: [.15,.30,.95], 117: [.15,.85,.25],
  118: [.28,.24,.20], 119: [.55,.32,.20], 120: [.45,.12,.10], 121: [.15,.28,.18], 122: [.22,.12,.08], 123: [.78,.62,.20],
  124: [1,.85,.50],   125: [.82,.68,.55], 126: [.06,.06,.07], 127: [.88,.86,.82], 128: [.12,.08,.06], 129: [.12,.20,.45],
  134: [.82,.88,.92], 137: [.10,.25,.45], 140: [.23,.49,.36], 141: [.14,.16,.15], 142: [.75,.78,.82], 143: [.18,.18,.19],
  144: [.96,.90,.69], 145: [.71,.16,.14], 146: [.42,.29,.18], 147: [.59,.67,.73] };
const BLDG_GLASS = new Set([112, 113, 114, 134, 147]);                  // glass ids — the voxEmit transparency contract
const darkMat = new THREE.MeshLambertMaterial({ color: 0x14161c });      // the Construct's furniture stock (consoles/kiosk)
const rodMat = new THREE.MeshLambertMaterial({ color: 0x2e3442 });       // machined piston rod — a half-tone off the barrel
MANIFEST.tables = [                                                    // PRIMARY TABLE — south flank of the door approach (-4.1,-1.1)
  { id: 'primary', x: -4.1, z: -1.1, size: 1.2, top: .26, scale: 1 / 64, mv: 2,   // scale = shared-table law; a model may declare `fill` instead —
    models: [{ name: 'tenement_block_0', fill: .75 }],                   // mounted exhibit — one model at a time, .75 of the tabletop
    catalog: [{ name: 'tenement_block_0', fill: .75 },                   // the swappable universe — the wall panel cycles it
              { name: 'barber_shop', fill: .75 }] },
  { id: 'block', x: -4.1, z: -3.9, size: 1.2, top: .26, scale: 1 / 64, mv: 3,   // BLOCK TABLE — north flank of the door approach (9 lots of 64 vox = 192 span)
    noSlice: true,                                                            // streets stay whole — roadProf's measured lanes are a whole-model law, a cut would orphan them
    ring: true,                                                               // static street exhibit: emitRing paints roads/curbs once, cars mount on it forever — swaps touch only the interior core
    parked: [{ edge: 's', along: 160 }, { edge: 'w', along: 140 }],             // the street scene is the TABLE's, not the model's —
    models: [{ name: 'block_26_tenement', fill: .75, slots: { 0: 'tenement_block_0' } }],   // every block composite carries the same roads + parked cars
    catalog: [{ name: 'block_26_tenement', fill: .75, slots: { 0: 'tenement_block_0' } },
              { name: 'block_41_barber', fill: .75, slots: { 2: 'barber_shop' } }] },       // block_41's authored lot — the rest = empty_land
  { id: 'studio', x: -6.5, z: -2.5, size: 2.4, top: .26, scale: 1 / 64, mv: 2,  // STUDIO TABLE — the ZONE tier centerpiece: 2.4m, dead-center of the expanded annex; a 3×3 rectangle of live city_layout blocks, "The Battlefield" (r3-5 × c0-2)
    noSlice: true,                                                            // zones + block composites are street models — same whole-road law
    models: [{ name: 'battlefield', fill: .75, plate: true, noProxy: true,      // plate: full-coverage ground → flat-tops path; noProxy: emitZone lays per-stamp proxies instead
               flip: false,                                                     // the Unity MAP renders chunks raw — the editor's fx mirror is a single-asset-view law, not a layout law
               zone: { src: 'city_layout.json', r0: 3, r1: 5, c0: 0, c1: 2 } }],
    catalog: [{ name: 'battlefield', fill: .75, plate: true, noProxy: true,
                flip: false,
                zone: { src: 'city_layout.json', r0: 3, r1: 5, c0: 0, c1: 2 } },
              { name: 'tenement_block_0', fill: .75 },
              { name: 'barber_shop', fill: .75 },
              { name: 'block_26_tenement', fill: .75, slots: { 0: 'tenement_block_0' } },
              { name: 'block_41_barber', fill: .75, slots: { 2: 'barber_shop' } }] },
];
const TABLES = [];
const SLEEVE_H = .12;                                                    // piston barrel — the fixed lower leg section
const emitTable = spec => {
  const g = new THREE.Group(); g.position.set(spec.x, 0, spec.z); scene.add(g);
  const s = spec.size, h = spec.top;
  const slab = new THREE.Mesh(new THREE.BoxGeometry(s, .04, s), darkMat); slab.position.y = h - .02; g.add(slab);
  const rods = [], legs = [];                                            // piston legs — barrel + collar + telescoping rod
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { const lg = new THREE.Group();
    lg.position.set(a * (s / 2 - .11), 0, b * (s / 2 - .11)); g.add(lg);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(.09, SLEEVE_H, .09), darkMat);
    sleeve.position.y = SLEEVE_H / 2; lg.add(sleeve);
    const collar = new THREE.Mesh(new THREE.BoxGeometry(.105, .02, .105), darkMat);   // the gland the rod slides through
    collar.position.y = SLEEVE_H; lg.add(collar);
    const rod = new THREE.Mesh(new THREE.BoxGeometry(.05, 1, .05), rodMat);            // unit-height rod — scale.y is the reach
    const len = h - .04 - SLEEVE_H; rod.scale.y = len; rod.position.y = SLEEVE_H + len / 2; lg.add(rod);
    rods.push(rod); legs.push(lg); });
  const rims = [];
  const w = BND_W * 1.6;                                                 // tabletop rim — the floor seam lifted to h, like the door ∩
  [[0, -1, s + w, w], [0, 1, s + w, w], [-1, 0, w, s + w], [1, 0, w, s + w]].forEach(([a, b, lx, lz]) => {
    const e = new THREE.Mesh(new THREE.BoxGeometry(lx, w, lz), coreMat);
    e.position.set(a * s / 2, h, b * s / 2); g.add(e); rims.push(e); });
  const block = { x0: spec.x - s / 2 - .15, x1: spec.x + s / 2 + .15,      // capsule-expanded footprint — exact square edge-slide
                  z0: spec.z - s / 2 - .15, z1: spec.z + s / 2 + .15 };
  WALL_BLOCKS.push(block);
  const tops = new Map();                                                // flat measured top at h over the whole footprint (5mm columns)
  const c0 = Math.round(-s / 2 * 200), c1 = Math.round(s / 2 * 200);
  for (let ix = c0; ix <= c1; ix++) for (let iz = c0; iz <= c1; iz++) tops.set(TOPK(ix, iz), h);
  const rec = { name: 'table:' + spec.id, kind: 'table', g, tops, lb: [-s / 2, s / 2, -s / 2, s / 2],
    x: spec.x, z: spec.z, rotY: 0, y0: 0, minB: 0, vs: 1, surf: true, topY: h,
    pendWant: spec.pendant !== false ? 1 : 0,                            // tables ship with the attached light — spec.pendant:false or P in place mode removes it
    bbox: footB([-s / 2, s / 2, -s / 2, s / 2], spec.x, spec.z, 0), pickable: false, solids: null, source: 'manifest', mv: spec.mv || 0, _block: block, _spec: spec };
  g.userData.pRec = rec; PLACED.push(rec);
  const t = { spec, rec, g, lift: 0, parts: { slab, rims, rods, legs } }; TABLES.push(t); return t;
};
/* tableTop = authored top + live lift — every top-derivation reads it (mount, tops, sync). */
const tableTop = t => t.spec.top + t.lift;
/* liftRiders — the column rides with its pedestal: anything standing above the old top inside the
   footprint shifts by the lift delta (stacked items keep their offsets — every level +same dy). */
const liftRiders = (t, dy, oldTop) => PLACED.forEach(q => {
  if (q === t.rec || q === held || q.mount || q.g.parent !== scene) return;  // a wall-mounted pad stays hung; parented scenery (parked cars, the spinner's car) rides its host's frame — inB reads local x/z against a world box
  if (inB(q, t.rec.bbox) && q.y0 >= oldTop - .005) { q.y0 += dy; q.g.position.y = q.y0; } });
/* tableLiftSet — the piston verb: geometry reposes, measured tops shift by delta, riders ride. */
const tableLiftSet = (t, lift) => { const oldTop = tableTop(t);
  t.lift = Math.max(-.22, Math.min(.4, lift));                            // floor notch: slab bottom reaches y=0 at H=.04
  const dy = tableTop(t) - oldTop; if (Math.abs(dy) < 1e-6) return;
  const H = tableTop(t), gap = H - .04;                                    // gap = the slab's underside
  t.parts.slab.position.y = H - .02;
  t.parts.rims.forEach(e => e.position.y = H);
  t.parts.legs.forEach((lg, i) => { const rod = t.parts.rods[i];
    lg.position.y = Math.min(0, gap - SLEEVE_H - .01);                     // past the collar tops the barrel sinks below the floor — full retraction
    const top = lg.position.y + SLEEVE_H, len = Math.max(.004, gap - top);
    rod.scale.y = len; rod.position.y = top + len / 2; });
  t.g.children.forEach(c => { if (c.userData.mini) c.position.y = H; });   // the exhibit rides its pedestal
  t.rec.tops.forEach((v, k) => t.rec.tops.set(k, v + dy));                 // measured surface follows the lift
  liftRiders(t, dy, oldTop);
  localStorage.setItem('dvm_lift:' + t.spec.id, String(t.lift)); };        // the height persists like the layout
const tableLift = (t, dy) => tableLiftSet(t, t.lift + dy);
/* ── spinLift — the rotator's shop-lift verb: deck, ring, and car rise together on a center
   post (same piston stock as table legs — floor base + telescoping rod under the invisible
   disc). The pendant does NOT ride: it's a scene fixture, the car rises INTO its beam.
   dvm_spinlift persists. Deck controls (spin + lift) live on the pad's DECK page. */
const SPIN_LIFT_MAX = .62;                                               // deck top ~.62 — car beltline above the .55 eye, roof still under the 1.2 dome
const liftCol = new THREE.Group(); liftCol.position.set(SPIN_POS.x, 0, SPIN_POS.z); scene.add(liftCol);
const liftBase = new THREE.Mesh(new THREE.CylinderGeometry(.17, .19, .05, 24), darkMat);
liftBase.position.y = .025; liftCol.add(liftBase);                       // flush lift pad — the column retracts into it at 0
const liftRod = new THREE.Mesh(new THREE.CylinderGeometry(.075, .075, 1, 16), rodMat);
liftCol.add(liftRod);
const spinLiftSet = y => { const ly = Math.max(0, Math.min(SPIN_LIFT_MAX, y));
  spinG.position.y = ly;
  const len = Math.max(.005, ly - .05);
  liftRod.visible = ly > .05; liftRod.scale.y = len; liftRod.position.y = .05 + len / 2;
  localStorage.setItem('dvm_spinlift', String(ly)); };
const spinLiftStep = d => spinLiftSet(spinG.position.y + d);
const spinCtl = v => { spinning = true; SPIN_RATE = v; };                // pad's deck spin: rate sign = direction
spinLiftSet(+localStorage.getItem('dvm_spinlift') || 0);
/* stassetFetch — one parsed volume per name, cached (a block's 9 slots share fetches:
   empty_land arrives once and stamps every vacant lot). Falls back through the
   vehicle dir, then voxel_items/<name>.json — variants and WIP models mount
   file-first without a stasset ever existing. */
const _stCache = {};
const _stParse = buf => { const dv = new DataView(buf);
  if (dv.getUint32(0, false) !== 0x53544153) throw new Error('not a stasset');
  const W = dv.getUint16(6, true), H = dv.getUint16(8, true), D = dv.getUint16(10, true);
  return { W, H, D, vox: new Uint16Array(buf.slice(16, 16 + W * H * D * 2)) }; };
const _jsonToVox = data => { const [W, H, D] = data.dims, vox = new Uint16Array(W * H * D);   // editor JSON → the same dense contract
  (data.voxels || []).forEach(([x, y, z, m]) => { if (x < W && y < H && z < D) vox[x + W * (y + H * z)] = m; });
  return { W, H, D, vox }; };
const _previewOf = {};                                                          // pad variant previews: canonical name → variant
const stassetFetch = name => { name = _previewOf[name] || name;                 // every emit resolves through the overlay — cycling a
  return _stCache[name] || (_stCache[name] =                                    // variant repaints all its dependents live; LOCK commits
  fetch('/Assets/StreamingAssets/voxel_buildings/' + name + '.stasset')
    .then(r => r.ok ? r.arrayBuffer().then(_stParse) :                                       // vehicles live one folder over —
      fetch('/Assets/StreamingAssets/voxel_vehicles/' + name + '.stasset')                   // baked 5cm derivatives (touring et al)
        .then(r2 => r2.ok ? r2.arrayBuffer().then(_stParse) :
          fetch('/voxel/' + name).then(r3 => r3.ok ? r3.json().then(_jsonToVox) :
            Promise.reject(new Error('404: ' + name)))))); };
/* emitBldg — a .stasset volume as a tabletop maquette. Dense u16 grid (STAS: x-major), surface-only
   instancing, per-column max-height written back into the host's tops. All models on a table share
   the table's declared scale — buildings stay comparable, like a real architect's set. */
const emitBldg = (t, m) => stassetFetch(m.name)
  .then(f => emitVox(t, m, f.W, f.H, f.D, f.vox))
  .then(g => { if (g) g.userData.mini._deps = new Set([m.name]); return g; })   // live-sync: the editor's strokes rebuild any mini listing this file
  .catch(e => console.warn('CONSTRUCT — bldg emit failed:', m.name, e));
/* BLK — the game's per-block terrain contract: slot 64, block interior 192 (3×3 lots),
   margin M = 65v (20v sidewalk + 45v half-road) → tile 322. emitBlock builds one tile;
   emitZone tiles them — the ground/lot recipe lives once in fillBlockGround/stampSlots. */
const BLK = { S: 64, BW: 192, SIDE: 20, ROAD: 45 }; BLK.M = BLK.SIDE + BLK.ROAD; BLK.TILE = BLK.BW + 2 * BLK.M;
/* BLKF — the single-block diorama's "far" variant: a lone block exhibit has no neighbor tile to
   supply the other half-street, so it paints BOTH halves itself (band = 2×ROAD: far half + seam
   at 45 + our half; stripes at each half's center = the dual lane lines seen in-game). The rim
   is the far curb — no far sidewalk (that's the neighbor's, outside this model). emitZone keeps
   strict seam law: interior seams already read as full streets and the perimeter is the cut. */
const BLKF = { S: BLK.S, BW: BLK.BW, SIDE: BLK.SIDE, ROAD: 2 * BLK.ROAD };
BLKF.M = BLKF.SIDE + BLKF.ROAD; BLKF.TILE = BLKF.BW + 2 * BLKF.M;
/* fillBlockGround — VoxelTerrainBuilder.GeneratePerBlockTerrain's recipe, one tile at (X0,Z0):
   each block owns its ground tile (20v sidewalk ring + stone plot) plus HALF the road on each
   side (45v asphalt, 1v cobble stripe centered in the half — two adjacent tiles' halves read as
   the dual lane lines). seams {n,e,s,w} = layout seam types ('road' stripes, anything else reads
   as a plain asphalt boulevard); lanes (bits N=1 E=2 S=4 W=8) cuts curb mouths + the interior
   lane cross-section for alley catalogs. */
const fillBlockGround = (set, X0, Z0, seams, lanes, B = BLK) => { const { ROAD, M, TILE } = B;
  for (let z = 0; z < ROAD; z++) for (let x = 0; x < TILE; x++) {          // FillCorridors — horizontal bands first…
    set(X0 + x, Z0 + z,           seams.n === 'road' && (z === 22 || z === ROAD - 23) ? 105 : 104);   // …cobble stripe centered in each half…
    set(X0 + x, Z0 + TILE - 1 - z, seams.s === 'road' && (z === 22 || z === ROAD - 23) ? 105 : 104); }
  for (let x = 0; x < ROAD; x++) for (let z = 0; z < TILE; z++) {          // …vertical strips own the corners
    set(X0 + x,         Z0 + z, seams.w === 'road' && (x === 22 || x === ROAD - 23) ? 105 : 104);
    set(X0 + TILE - 1 - x, Z0 + z, seams.e === 'road' && (x === 22 || x === ROAD - 23) ? 105 : 104); }
  const m0 = M + 80, m1 = M + 112, L0 = M + 64, L1 = M + 128;
  for (let z = ROAD; z < TILE - ROAD; z++) for (let x = ROAD; x < TILE - ROAD; x++) {   // FillGroundTile
    const eW = x < M, eE = x >= TILE - M, eS = z < M, eN = z >= TILE - M;
    let id = 101;
    if (eW || eE || eS || eN) {                                        // sidewalk ring — curb cuts at mouths
      const mouth = (eW && (lanes & 8) && z >= m0 && z < m1) || (eE && (lanes & 2) && z >= m0 && z < m1) ||
                    (eS && (lanes & 4) && x >= m0 && x < m1) || (eN && (lanes & 1) && x >= m0 && x < m1);
      id = mouth ? 104 : 102;
    } else if (lanes) {                                                // interior lane cross-section
      if ((lanes & 10) && z >= L0 && z < L1) id = (z >= m0 && z < m1) ? 104 : 102;
      else if ((lanes & 5) && x >= L0 && x < L1) id = (x >= m0 && x < m1) ? 104 : 102; }
    set(X0 + x, Z0 + z, id); } };
/* stampSlots — a block's 3×3 lots into its interior (origin X0,Z0 = the tile's corner in the
   composite grid; the composite stride is W2, slab offset +2). Each explicit slot stamps its
   asset at its 64-voxel offset; a multi-slot asset marks every lot it covers; the rest take
   empty_land — the game's own vacant-lot tile. Returns the per-stamp rects for aim proxies. */
const stampSlots = (vox, W2, H, files, slots, X0, Z0, B = BLK, zFlip = false, mir = false, collect = null) => { const { S, BW, M } = B;
  const covered = new Set();                                          // which lots does explicit content already own?
  const rOf = (s, f) => zFlip ? 3 - (s / 3 | 0) - f.D / S : (s / 3 | 0);  // Unity's index-row0 sits on the block edge TOWARD row+1 — under our row↑→+z grid that's the z-max side, so zone lots flip their row (footprint-aware: a 3-row tenement still spans 0..2)
  Object.entries(slots).forEach(([s, n]) => { const f = files[n], sc = +s % 3, r0 = rOf(s, f);
    for (let r = r0; r < r0 + f.D / S; r++) for (let c = sc; c < sc + f.W / S; c++) covered.add(r * 3 + c); });
  const stamped = [], stamp = (f, sx, sz, n) => {
    const rec = { x: X0 + M + sx, z: Z0 + M + sz, w: Math.min(f.W, BW - sx), d: Math.min(f.D, BW - sz), h: f.H, n };
    if (collect && n) { collect.push(rec); return; }                    // surgical mode — positions only; the
    stamped.push(rec);                                                  // building emits as its own sub-mini
    for (let z = 0; z < f.D && sz + z < BW; z++)
      for (let y = 0; y < f.H; y++) for (let x = 0; x < f.W && sx + x < BW; x++) {
        const id = f.vox[x + f.W * (y + f.H * (mir ? f.D - 1 - z : z))];          // mir: stamp content z-mirrors inside its own footprint — the Unity L/R flip moves fronts to the lot's far edge and leaves text + door/pole x-positions reading correctly — while the lot's position stays raw (zone composite renders flip:false)
        if (id) vox[(X0 + M + sx + x) + W2 * (y + 2 + H * (Z0 + M + sz + z))] = id; } };
  for (let s = 0; s < 9; s++) { const n = slots[s]; if (n) { const f = files[n]; stamp(f, (s % 3) * S, rOf(s, f) * S, n); } }
  for (let s = 0; s < 9; s++) if (!covered.has(s) && !slots[s]) stamp(files['empty_land'], (s % 3) * S, ((s / 3) | 0) * S);
  return stamped; };
/* roadProf — the street's own geometry, measured off the composite's column tops: the
   sidewalk is the raised run hugging the property line inside each road band (the plate's
   flat cells never list in localCols). Per edge {road, dir}: `road` = the cell the car's
   curb edge sits on (just lane-side of the strip); `dir` = which way the lane runs. The
   bare band law parked cars straddling the strip — wheels under the curb = sunken look. */
const roadProf = mn => { if (mn._road) return mn._road;                            // cached for the mount's life — legal BECAUSE street tables are noSlice: a cut could never retire a lane
  const W = mn.dims[0], D = mn.dims[2], CURB = 4;
  if (!mn._colTop) { const T = mn._colTop = new Int16Array(W * D).fill(-1);
    mn.localCols.forEach(c => { T[c.x + W * c.z] = Math.max.apply(null, c.ys); }); }
  const T = mn._colTop, R = {};
  [['s', 0, D - 1, 1], ['e', 1, W - 1, 1], ['n', 0, 0, -1], ['w', 1, 0, -1]].forEach(q => {
    const e = q[0], ax = q[1], t0 = q[2], rd = q[3], span = ax ? D : W,             // rd = rim direction; scan runs INWARD — the first raised run off the rim is our curb strip (a diorama's far half is flat and reads as nothing)
      probes = [.25, .375, .5, .625, .75].map(f => Math.round(span * f));
    let first = -1, last = -1, flat = 0;
    for (let t = t0, i = 0; i < 140 && t >= 0 && t <= (ax ? W : D) - 1; t -= rd, i++) {
      const raised = probes.filter(u => (ax ? T[t + W * u] : T[u + W * t]) > CURB).length >= 3;
      if (raised) { if (first < 0) first = t; last = t; flat = 0; }
      else if (first >= 0 && ++flat > 4) break; }
    if (first >= 0) R[e] = { road: first + rd, dir: rd }; });                      // road = our half's curb-side boundary cell
  return Object.keys(R).length ? mn._road = R : R; };                              // a found-nothing scan isn't worth caching — a fuller localCols may yet see strips
/* blockTrf — a curbside cruise for the table's parked cars: pull out of the slot, lap the
   right-of-travel lanes, pull back in. The circuit is the MEASURED street (roadProf's lane
   centers + quarter arcs at the corners) — the game's road files carry no lane/direction
   data, so the lanes are the part we derive here. Cars stay miniG-parented — spin/lift/swap
   ride free; positions are cell coords converted through mn.fx exactly like the mount did. */
const LEAD = 1.2 / BLDG_VS;                                                                  // Unity's maneuver lead 1.2 m → composite cells (RequestDepart merge / TrySpliceParking approach)
const blockTrf = { on: false, mn: null, g: null, L: null, segs: [], len: 0, cars: [], V: 3.0,   // V = real m/s — Unity VehicleTestSpawner.driveSpeed = 3.0f
  build(mn) { const R = roadProf(mn), HALF = BLK.ROAD * .5, r = 10, D = mn.dims,               // lane center = road-half center (roadWidth/4 off the street centerline) — the cobble stripe IS the lane line
      off = (mn._blkM || BLK.M) - BLK.SIDE - HALF,                                             // bare-band fallback: our-half center = margin − sidewalk − half-half
      L = { s: R.s ? R.s.road + HALF : D[2] - off, n: R.n ? R.n.road - HALF : off,
            e: R.e ? R.e.road + HALF : D[0] - off, w: R.w ? R.w.road - HALF : off },
      leg = (ax, f, a0, a1, hx, hz) => ({ ax, f, a0, a1, hx, hz, len: Math.abs(a1 - a0) }),
      arc = (cx, cz, a0, sgn) => ({ cx, cz, r, a0, sgn, len: r * Math.PI / 2 }),
      segs = [ leg('x', L.s, L.w + r, L.e - r, 1, 0),  arc(L.e - r, L.s - r, 90, -1),       // the RENDERED circuit is right-hand traffic: cell space runs
               leg('z', L.e, L.s - r, L.n + r, 0, -1), arc(L.e - r, L.n + r, 0, -1),       // counterclockwise (s→e→n→w), arcs sweep negative — the fx
               leg('x', L.n, L.e - r, L.w + r, -1, 0), arc(L.w + r, L.n + r, 270, -1),     // mirror turns it clockwise with right turns on screen
               leg('z', L.w, L.n + r, L.s - r, 0, 1),  arc(L.w + r, L.s - r, 180, -1) ];
    let s = 0; segs.forEach(g => { g.s0 = s; s += g.len; });
    this.L = L; this.segs = segs; this.len = s; this.mn = mn; this.r = r; },
  at(s) { s = ((s % this.len) + this.len) % this.len;
    const g = this.segs.find(q => s < q.s0 + q.len) || this.segs[this.segs.length - 1], t = s - g.s0;
    if (g.ax) { const d = g.a1 > g.a0 ? 1 : -1, a = g.a0 + d * t;
      return g.ax === 'x' ? { x: a, z: g.f, hx: g.hx, hz: g.hz } : { x: g.f, z: a, hx: g.hx, hz: g.hz }; }
    const a = (g.a0 + g.sgn * t / g.r * 180 / Math.PI) * Math.PI / 180;
    return { x: g.cx + g.r * Math.cos(a), z: g.cz + g.r * Math.sin(a), hx: -Math.sin(a) * g.sgn, hz: Math.cos(a) * g.sgn }; },
  stn(sc, lead) { const L = this.L, r = this.r, x = sc.edge === 's' || sc.edge === 'n';   // maneuver endpoints, Unity's law: depart merges at lanePos + dir·lead, park splices at lanePos − dir·lead
    const a = x ? Math.min(Math.max(sc.cx + sc.hx * lead, L.w + r + 2), L.e - r - 2)      // clamped inside the straight leg so sOf always resolves
                : Math.min(Math.max(sc.cz + sc.hz * lead, L.n + r + 2), L.s - r - 2);
    return x ? { x: a, z: sc.edge === 's' ? L.s : L.n }
             : { x: sc.edge === 'w' ? L.w : L.e, z: a }; },
  sOf(p) { const g = this.segs.find(q => q.ax &&
      (q.ax === 'x' ? Math.abs(p.z - q.f) < .5 && Math.min(q.a0, q.a1) <= p.x && p.x <= Math.max(q.a0, q.a1)
                    : Math.abs(p.x - q.f) < .5 && Math.min(q.a0, q.a1) <= p.z && p.z <= Math.max(q.a0, q.a1)));
    return g ? g.s0 + Math.abs((g.ax === 'x' ? p.x : p.z) - g.a0) : 0; },
  /* toggle — the CARS press is GLOBAL, not aimed at a table: the cruise lives wherever the
     parked recs live, so the host miniG is whichever table's current mini actually parents
     _parked recs — padTable()'s nearest-table guess can resolve a car-less table mid-session
     and a wrong-table call must never rebuild a live cruise's circuit. */
  toggle(t, on) { const p0 = PLACED.find(p => p._parked && p._slotC && p.g && p.g.parent),
      g = p0 && p0.g.parent, mn = g && g.userData.mini;                        // the parked rec knows its host group — the static street ring (a table may carry several minis now)
    this.on = on === undefined ? !this.on : !!on;
    if (!mn) { this.on = false; return false; }
    this.build(mn); this.g = g;
    if (!this.on) return false;                                                // off = cruise out the lap, park on arrival — cars keep their state
    this.cars = PLACED.filter(p => p._parked && p._slotC && p.g.parent === g).map(p => {
      const sc = p._slotC, Pd = this.stn(sc, LEAD), Pa = this.stn(sc, -LEAD), sl = p._slot;
      p.g.position.x = sl.x; p.g.position.z = sl.z; p.g.rotation.y = sl.rotY;   // re-arm restarts from the curb
      return { rec: p, st: 'wait', delay: 0, s: 0, sD: this.sOf(Pd), sA: this.sOf(Pa), prog: 0, yaw: sl.rotY, tgt: null,   // delay 0 — Unity departs every car on the same keypress, together
        slot: [sc.cx, sc.cz], dPt: [Pd.x, Pd.z], aPt: [Pa.x, Pa.z],
        lenD: Math.hypot(Pd.x - sc.cx, Pd.z - sc.cz) || 1, lenA: Math.hypot(Pa.x - sc.cx, Pa.z - sc.cz) || 1 }; });
    this.inv = null;                                                           // claims live on inv entries — fresh lattice next off-session
    if (!this.cars.length) this.on = false;
    return this.on; },
  seek() { this.cars.forEach(c => { if (c.st === 'loop') c.s = (c.tgt ? c.tgt.sA : c.sA) - 2; }); },
  /* slotMap — the inv lattice with per-slot maneuver endpoints (approach/merge s, leg lens,
     home pose) precomputed once per off-session — stn/sOf need the live circuit. */
  slotMap() { const c0 = this.cars[0] && this.cars[0].rec._slotC; if (!c0) return [];
    return slotInv(this.mn, c0.carW, c0.carL).map(sc => {
      const Pd = this.stn(sc, LEAD), Pa = this.stn(sc, -LEAD);
      return { sc, sD: this.sOf(Pd), sA: this.sOf(Pa), aPt: [Pa.x, Pa.z], dPt: [Pd.x, Pd.z],
        home: [sc.cx, sc.cz], by: null,
        lenA: Math.hypot(Pa.x - sc.cx, Pa.z - sc.cz) || 1,
        lenD: Math.hypot(Pd.x - sc.cx, Pd.z - sc.cz) || 1 }; })
    .filter(sl => sl.sA > .5); },                                                    // an approach that misses every leg (sOf→0) is a dead target — the crossing test can never fire on it
  /* held — physical occupancy of a lattice slot: any _parked rec seated on/near it along the
     curb axis. 'leave'/'loop' recs already released (Unity releases at RequestDepart); a
     'park'-state rec counts by its DESTINATION, not its origin. */
  held(sc) { const ax = sc.axis === 'x' ? 'cx' : 'cz';
    return PLACED.some(p => { if (!p._parked || !p._slotC || !p.g || p.g.parent !== this.g || p._slotC.edge !== sc.edge) return false;
      const o = this.cars.find(k => k.rec === p);
      if (o && (o.st === 'leave' || o.st === 'loop')) return false;
      const cs = o && o.st === 'park' && o.tgt ? o.tgt.sc : p._slotC;
      return Math.abs(cs[ax] - sc[ax]) < (sc.carL + cs.carL) / 2 + 4; }); },
  /* claim — NearestFreeAhead's law: of the free lattice slots, the one whose approach-s has
     the smallest forward wrap distance. Overshot slots wrap to ~len and lose naturally; an
     all-held inventory returns null and the car keeps seeking — same as Unity. */
  claim(c, s) { const inv = this.inv || (this.inv = this.slotMap()); let best = null, bd = Infinity;
    const heldAx = new Set();                                              // precompute held slots ONCE per claim — held() iterated PLACED+cars per slot (O(inv × PLACED × cars))
    for (const sl of inv) if (this.held(sl.sc)) heldAx.add(sl);
    inv.forEach(sl => { if (sl.by || heldAx.has(sl)) return;
      const dS = (sl.sA - s + this.len) % this.len;
      if (dS < bd) { bd = dS; best = sl; } });
    if (best) best.by = c.rec; return best; },
  snap(c) { const rec = c.rec, mn = this.mn, D2 = mn.dims[2], vs = mn.vs, mir = mn.mirX ? -1 : 1;
    if (c.tgt && c.tgt.by === rec) { const sc = c.tgt.sc;                        // arrived at a claimed slot — adopt it as the new home slot
      rec._slotC = sc;
      rec._slot = { x: mn.fx(sc.cx) * vs, z: (sc.cz - D2 / 2) * vs, rotY: Math.atan2(sc.hx * mir, sc.hz) };
      c.tgt.by = null; }
    c.tgt = null;
    const sl = rec._slot; rec.g.position.x = sl.x; rec.g.position.z = sl.z;
    rec.g.rotation.y = sl.rotY; c.st = 'slot'; },
  tick(dt) { if (!this.cars.length || !this.mn) return;
    const mn = this.mn, vs = mn.vs, vc = this.V / BLDG_VS, D2 = mn.dims[2], mir = mn.mirX ? -1 : 1,
      putY = (g, x, z, yaw) => { g.position.x = mn.fx(x) * vs; g.position.z = (z - D2 / 2) * vs; g.rotation.y = yaw; },
      put = (g, x, z, hx, hz) => putY(g, x, z, Math.atan2(hx * mir, hz));              // authored front = +z (Unity LookRotation drives +z onto dir) — the −z law ran cars tail-first
    const loopCars = this.cars.filter(c => c.st === 'loop');                 // hoist the filter — was re-tested per car × per other car (O(n²) filter on the inner loop)
    this.cars.forEach(c => { const g = c.rec.g;
      if (!g || g.parent !== this.g) { c.st = 'gone'; return; }
      if (c.st === 'wait') { if (!this.on) { c.st = 'slot'; return; }
        if ((c.delay -= dt) <= 0) { c.st = 'leave'; c.yaw = g.rotation.y;
          c.a = c.slot; c.b = c.dPt; c.len = c.lenD; } return; }                          // the departure diagonal — slot → merge point
      if (c.st === 'leave' || c.st === 'park') { const fw = c.st === 'leave' ? this.on : true,
          a = c.a, b = c.b, len = c.len;                                                 // the diagonal legs — position lerps straight, yaw slerps onto the leg dir (Unity Slerp→LookRotation(seg) @6/s → the visible angle)
        c.prog += (fw ? 1 : -1) * vc * dt / len;                                       // same vc = 3.0 m/s — maneuvers run at drive speed
        if (c.prog >= 1) { if (c.st === 'park') { this.snap(c); return; } c.s = c.sD; c.st = 'loop'; c.tgt = null; return; }
        if (c.prog <= 0) { this.snap(c); return; }
        const x = a[0] + (b[0] - a[0]) * c.prog, z = a[1] + (b[1] - a[1]) * c.prog,
          sgn = fw ? 1 : -1, ty = Math.atan2((b[0] - a[0]) * sgn * mir, (b[1] - a[1]) * sgn),
          dw = ty - c.yaw, wr = Math.atan2(Math.sin(dw), Math.cos(dw));
        c.yaw += wr * Math.min(1, 6 * dt);
        putY(g, x, z, c.yaw); return; }
      if (c.st === 'loop') { let v = vc;
        for (const o of loopCars) { if (o === c) continue;                 // was this.cars.forEach + st==='loop' test per pair — hoisted filter cuts the inner work
          const d = ((o.s - c.s) % this.len + this.len) % this.len;
          if (d > 0 && d < 30) v = Math.min(v, vc * Math.max(0, (d - 8) / 22)); }
        const prev = c.s, ns = prev + v * dt;
        if (!this.on) {
          if (!c.tgt) c.tgt = this.claim(c, ns) ||                                     // park-anywhere: claim the nearest free slot ahead —
            { sc: c.rec._slotC, sA: c.sA, aPt: c.aPt, home: c.slot, lenA: c.lenA, by: null };   // empty/failed lattice still parks it at home
          if (c.tgt && prev < c.tgt.sA && ns >= c.tgt.sA) {                            // the lane crosses the claimed approach — splice the pull-in
            c.st = 'park'; c.prog = 0; c.yaw = g.rotation.y;
            c.a = c.tgt.aPt; c.b = c.tgt.home; c.len = c.tgt.lenA; return; } }
        c.s = ns % this.len; const q = this.at(c.s); put(g, q.x, q.z, q.hx, q.hz); } }); } };
/* mountParked — the game's curbside parking law, rendered as full-fidelity overlay
   miniatures rather than composite cells: the authored 1 cm asset mounts at the
   composite's own display scale (vs × voxelSize/BLDG_VS — every authored voxel present,
   just drawn smaller). Position law (ParkingMap.Build): parkOffset = roadWidth/2 − carW/2
   off the lane center + curb-push → center 50v − carW/2 off the block boundary; heading
   per edge is the legal right-side-of-travel direction (cell space — fx mirrors x); the
   KeepClear 40v no-park margin clamps `along`. Parented to miniG → spin/lift/swap ride
   free; the car is a real PLACED host, so items seat on it through surfaceAt. */
const PARK_CLEAR = 40;
/* PARK_EDGE — per-edge curb law in cell space: heading = the legal right-of-travel direction
   (mirrored to world by fx downstream). axis = which coordinate runs along the street. */
const PARK_EDGE = { s: { axis: 'x', hX: 1, hZ: 0 },  n: { axis: 'x', hX: -1, hZ: 0 },      // rendered-RHT law: fx mirrors x, so the cell-space
                    e: { axis: 'z', hX: 0, hZ: -1 }, w: { axis: 'z', hX: 0, hZ: 1 } };     // headings must read LEFT-handed for the mirrored view
                                                                                          // to show right-side parking + right turns (a mirrored RHT renders LHT)
/* PARK_PUSH — Unity's `extraParkOffset = 0.25f` (`ParkingMap.s.pos = station + side·(parkOffset
   + extraOffset)`): the parked center slides .25 m PAST the curb face, so the curb-side wheels
   overhang the sidewalk edge — the game's parked stance, not a flush park. */
const PARK_PUSH = Math.round(.25 / BLDG_VS);                                             // .25 m → 5 cells
/* curbC — the one curb law mounts and slots share: the measured strip's lane edge when the
   model carries a raised sidewalk, else the band's inner boundary. Flat-ground composites
   (barber's localCols lists interior cells only — no raised strip exists to find) still park
   at the real curb. `h` carries PARK_PUSH — the home point sits .25 m curb-ward of flush. */
const curbC = (e, mn, carW) => { const st = roadProf(mn)[e], h = Math.max(carW / 2 - PARK_PUSH, 0),
      ib = (mn._blkM || BLK.M) - BLK.SIDE;
    return st ? (st.dir > 0 ? st.road + h : st.road - h)
              : { s: mn.dims[2] - ib + h, n: ib - h, e: mn.dims[0] - ib + h, w: ib - h }[e]; };
/* slotInv — ParkingMap.Build's law: a fixed lattice of curbside slots per edge, carL+gap pitch
   (Unity's carLength + .5 gap ≈ 2.0 m) inside the keep-clear margins, curb position from the
   same curbC law the mounts use. Each slot is sc-shaped — stn()/the park path read
   it exactly like an authored _slotC. */
const slotInv = (mn, carW, carL) => { const W = mn.dims[0], D = mn.dims[2],
      ib = (mn._blkM || BLK.M) - BLK.SIDE, pitch = carL + Math.ceil(.5 / BLDG_VS), S = [];
    for (const e of ['s', 'n', 'e', 'w']) { const E = PARK_EDGE[e],
      c = curbC(e, mn, carW), dim = E.axis === 'x' ? W : D,
        lo = ib + PARK_CLEAR + carL / 2, hi = dim - ib - PARK_CLEAR - carL / 2;
      for (let a = lo; a <= hi; a += pitch)
        S.push({ edge: e, axis: E.axis, hx: E.hX, hz: E.hZ, carW, carL, along: a,
                 cx: (E.axis === 'x' ? a : c) - .5, cz: (E.axis === 'x' ? c : a) - .5 }); }
    return S; };
const _vehC = {};
const vehFetch = name => _vehC[name] || (_vehC[name] = fetch(ROUTES.vehicle + name).then(r => r.json()));
const mountParked = (t, miniG, parked) => { const mn = miniG.userData.mini, vs = mn.vs,
      W2 = mn.dims[0], D2 = mn.dims[2], MM = mn._blkM || BLK.M, ib = MM - BLK.SIDE;
  return Promise.all((parked || []).map(p => { const E = PARK_EDGE[p.edge]; if (!E) return null;   // AWAITED — _mountP covers the whole street, extras seat on car roofs at boot
    return vehFetch(p.name || 'vehicle_490_touring').then(veh => {
      const cvs = (veh.voxelSize || .01) / BLDG_VS,                                      // car cells per composite cell (1:5 for the touring)
            carW = veh.dims[0] * cvs, carL = veh.dims[2] * cvs;                          // real footprint in composite cells
      const lo = ib + PARK_CLEAR + carL / 2, hi = (E.axis === 'x' ? W2 : D2) - ib - PARK_CLEAR - carL / 2,
        a = Math.max(lo, Math.min(hi, p.along == null ? (lo + hi) / 2 : p.along)),
        c = curbC(p.edge, mn, carW),                                                     // hug the STRIP's lane edge — the bare band law straddled the curb
        cx = (E.axis === 'x' ? a : c) - .5, cz = (E.axis === 'x' ? c : a) - .5;            // cell-space center → cell coords
      const vvs = vs * cvs,                                                              // authored voxel at the composite's scale
        hx = mn.mirX ? -E.hX : E.hX, hz = E.hZ,                                          // fx mirrors x — cell headings mirror with it
        rotY = Math.atan2(hx, hz);                                                     // authored front = +z (Unity LookRotation drives +z onto dir) → rotate onto the heading
      return emitAsset(p.name || 'vehicle_490_touring', { kind: 'vehicle', parent: miniG,
        x: mn.fx(cx) * vs, z: (cz - D2 / 2) * vs, rotY, seatY: 2 * vs + vvs * 1.5, vsOverride: vvs, pickable: false, source: 'parked' })   // +1.5 car-voxels: at grazing angles the black tire ring merges into the road's dark top — flush and half-voxel both read sunk; a voxel-and-a-half of air lets the whole ring draw against the road face
        .then(rec => { if (!rec) return;
          if (!miniG.parent) { const i = PLACED.indexOf(rec); if (i >= 0) PLACED.splice(i, 1); rec.g.parent && rec.g.parent.remove(rec.g); return; }   // model swapped mid-fetch — no ghost cars
          rec._parked = true;
          rec._slot = { x: rec.g.position.x, z: rec.g.position.z, rotY };                 // the exact curb pose — repark restores it verbatim
          rec._slotC = { cx, cz, edge: p.edge, hx: E.hX, hz: E.hZ, carW, carL };          // cell-space slot + heading — the cruise circuit's frame
          rec.g.children.forEach(ch => { ch.userData.miniVox = true; });                  // pruned aim — 78k cells never ray-test
          const pw = (E.axis === 'x' ? veh.dims[2] : veh.dims[0]) * vvs,                   // proxy footprint swaps on quarter-turn
                pd = (E.axis === 'x' ? veh.dims[0] : veh.dims[2]) * vvs, ph = veh.dims[1] * vvs;
          rec.g.add(hitProxy(pw + vvs, ph, pd + vvs, 0, ph / 2, 0)); }); })                  // the proxy rides the car — it can drive now
      .catch(e => console.warn('CONSTRUCT — parked mount failed:', p.name, e)); })); };      // one bad car sinks neither its siblings nor the block
/* emitRing — the block table's STATIC street exhibit: the BLKF diorama ground (roads, curbs,
   sidewalks, the empty interior pad) with NO lot stamps. Emitted once for the table's life;
   parked cars mount on it and survive every model swap. `mn.static` keeps it out of the
   unmount sweep; `_road = {}` pins the flat-scan truth (no raised strips exist) so curbC/
   slotInv/blockTrf all run the deterministic band law — identical for every core. */
const emitRing = (t, fill) => { const W2 = BLKF.TILE, H = 4;
  const vox = new Uint16Array(W2 * H * W2);
  const set = (x, z, id) => { vox[x + W2 * (H * z)] = vox[x + W2 * (1 + H * z)] = id; };
  fillBlockGround(set, 0, 0, { n: 'road', e: 'road', s: 'road', w: 'road' }, 0, BLKF);
  return emitVox(t, { name: 'street_ring', fill, plate: true, _blkM: BLKF.M, static: true }, W2, H, W2, vox)
    .then(ringG => { if (ringG) { const mn = ringG.userData.mini; mn._road = {}; t._ringVs = mn.vs; } return ringG; })
    .catch(e => { (window.__emitErr = window.__emitErr || []).push('ring:' + (e && e.stack || e)); console.warn('CONSTRUCT — ring emit failed:', e); }); };
/* emitCore — a block model's interior only: its 3×3 lots stamped into the 192-cell core that
   seats inside the table's static ring (same center; _vs pins the ring's voxel size so the
   two minis' cells align 1:1). The swap target — every block model shares the ring's roads. */
const emitCore = (t, m) => { const BW2 = BLK.BW, slots = m.slots || {};
  const names = new Set(['empty_land']); Object.values(slots).forEach(n => names.add(n));
  return Promise.all([...names].map(n => stassetFetch(n).then(f => [n, f]))).then(es => {
    const files = Object.fromEntries(es);
    const H = Math.max(2, Math.max(...[...names].map(n => files[n].H)) + 2);             // +2: the slab pair — stamps sit at y+2 flush on the ring's pad
    const vox = new Uint16Array(BW2 * H * BW2);
    stampSlots(vox, BW2, H, files, slots, 0, 0, { S: BLK.S, BW: BW2, M: 0 });
    return emitVox(t, { ...m, _vs: t._ringVs, plate: true }, BW2, H, BW2, vox)
      .then(g => { if (g) g.userData.mini._deps = names; return g; }); })       // live-sync deps = every stasset stamped into this core
    .catch(e => console.warn('CONSTRUCT — block core emit failed:', m.name, e)); };
/* emitBlock — a 3×3 city block as ONE miniature: the tile recipe + lot stamps merged into a
   single composite at 1:1, tops written back into the host. ROT/SLICE/persistence unchanged.
   The non-ring path — a block composite mounted on a ring-less table (e.g. studio) still
   carries its own streets. */
const emitBlock = (t, m) => { const W2 = BLKF.TILE, slots = m.slots || {};
  const parked = (t.spec.parked || []).concat(m.parked || []);                 // the street scene is the TABLE's — every block composite carries it; a spec can still add
  const names = new Set(['empty_land']); Object.values(slots).forEach(n => names.add(n));
  return Promise.all([...names].map(n => stassetFetch(n).then(f => [n, f]))).then(es => {
    const files = Object.fromEntries(es);
    const H = Math.max(2, Math.max(...[...names].map(n => files[n].H)) + 2);
    const vox = (t._voxPool && t._voxPool.length === W2 * H * W2) ? t._voxPool.fill(0) : (t._voxPool = new Uint16Array(W2 * H * W2));
    const set = (x, z, id) => { vox[x + W2 * (H * z)] = vox[x + W2 * (1 + H * z)] = id; };
    fillBlockGround(set, 0, 0, { n: 'road', e: 'road', s: 'road', w: 'road', ...(m.seams || {}) }, m.lanes | 0, BLKF);
    stampSlots(vox, W2, H, files, slots, 0, 0, BLKF);
    return emitVox(t, { ...m, plate: true, _blkM: BLKF.M }, W2, H, W2, vox)   // composites have full-coverage ground — the flat tops path applies
      .then(miniG => { if (miniG) miniG.userData.mini._deps = names; return miniG; })   // live-sync deps
      .then(miniG => miniG ? mountParked(t, miniG, parked).then(() => miniG) : miniG); })   // cars overlay + AWAITED — authored fidelity, never downsampled
    .catch(e => { (window.__emitErr = window.__emitErr || []).push('block:' + (e && e.stack || e)); console.warn('CONSTRUCT — block emit failed:', m.name, e); }); };
/* layoutFetch — the live city layout (blocks+seams) is the zone's sole source of truth, cached. */
const _layoutC = {};
const layoutFetch = file => _layoutC[file] || (_layoutC[file] =
  fetch('/Assets/StreamingAssets/' + file).then(r => r.json()));
/* emitZone — an r0..r1 × c0..c1 rectangle of city_layout blocks ("a zone" — the drafting
   room's third tier). Two-tier emit since the surgical restamp: the GROUND composite (roads,
   curbs, sidewalks, empty lots — one emitVox) + each authored building as its own sub-mini
   inside the zone group. rebuildDeps then re-emits only the changed name's children —
   a barber stroke repaints ~150k cells, not the whole 37M-cell city. Ground deps = every
   stamped name anyway (a dep hit on a stamped name goes surgical; ground-level names like
   empty_land still full-remount). */
const emitZone = (t, m) => { const { M, TILE } = BLK, z = m.zone;
  const R = z.r1 - z.r0 + 1, C = z.c1 - z.c0 + 1, W2 = C * TILE, D2 = R * TILE;
  return layoutFetch(z.src || 'city_layout.json').then(L => {
    const blks = L.blocks.filter(b => b.row >= z.r0 && b.row <= z.r1 && b.col >= z.c0 && b.col <= z.c1);
    const stName = s => (s.stasset || s.type + '.stasset').split('/').pop().replace(/\.stasset$/, '');   // layout stores paths — basename is the fetch name
    const names = new Set(['empty_land']);
    blks.forEach(b => b.buildings.forEach(s => names.add(stName(s))));
    return Promise.all([...names].map(n => stassetFetch(n).then(f => [n, f]))).then(async es => {
      const files = Object.fromEntries(es);
      const H = 2 + files['empty_land'].H;                                   // buildings moved to sub-minis — the ground
      const vox = (t._voxPool && t._voxPool.length === W2 * H * D2) ? t._voxPool.fill(0)   // composite only needs slab+empty_land rows
        : (t._voxPool = new Uint16Array(W2 * H * D2));
      const set = (x, zz, id) => { vox[x + W2 * (H * zz)] = vox[x + W2 * (1 + H * zz)] = id; };
      const hAt = (r, c) => (r >= 0 && r < L.hSeamRows.length && c >= 0 && c < L.hSeamRows[r].cells.length) ? L.hSeamRows[r].cells[c] : 'road';
      const vAt = (r, c) => (r >= 0 && r < L.vSeamRows.length && c >= 0 && c < L.vSeamRows[r].cells.length) ? L.vSeamRows[r].cells[c] : 'road';
      const collect = [];                                                  // occupied slots → positions only, no grid write
      let bi = 0;
      for (const b of blks) { const X0 = (b.col - z.c0) * TILE, Z0 = (b.row - z.r0) * TILE;   // Unity anchors row→−z in ITS world — but the in-game compass reads that as SOUTH-ward: our room's +z is the matching edge (verified vs the west-facing in-game shot: r5 tenement sits LEFT)
        const seams = { n: hAt(b.row - 1, b.col), e: vAt(b.row, b.col), s: hAt(b.row, b.col), w: vAt(b.row, b.col - 1) },
          slots = {}, types = new Set(); b.buildings.forEach((s, i) => { slots[i] = stName(s); types.add(s.type); });   // Unity positions buildings by ARRAY INDEX (slot field is metadata)
        const lanes = (types.has('alley_lane') ? 10 : 0) | (types.has('alley_lane_ns') ? 5 : 0);   // a lane slot IS the cut — the stasset is an empty placeholder; the mouth+cross-section draw in the ground recipe
        fillBlockGround(set, X0, Z0, seams, lanes);
        stampSlots(vox, W2, H, files, slots, X0, Z0, BLK, true, true, collect);   // zFlip lots + z-mir content — the sub-minis reproduce it as flip:false + zflip
        if (!(++bi & 3)) await new Promise(r => setTimeout(r)); }   // ~4 blocks per turn
      return emitVox(t, m, W2, H, D2, vox).then(async miniG => {
        if (!miniG) return miniG;
        const mn = miniG.userData.mini, vs = mn.vs;
        mn._deps = names;                                                  // live-sync deps = every stamped stasset
        mn._subs = []; mn._byName = new Map();                             // surgical registry — rebuildDeps restamps per name
        miniG.add(hitProxy(W2 * vs, 2 * vs, D2 * vs, 0, vs, 0));             // ground plate — roads/lots aim at slab top
        for (const st of collect) { const f = files[st.n];
          const g = await emitVox(t, { name: st.n, _vs: vs, flip: false, zflip: true, _parent: miniG, _py: 2 * vs, noProxy: true,
            x: (st.x + st.w / 2 - W2 / 2) * vs, z: (st.z + st.d / 2 - D2 / 2) * vs }, f.W, f.H, f.D, f.vox);
          if (!g) return miniG;                                            // a full remount landed mid-build — it owns the subs
          g.userData.mini._deps = new Set([st.n]); g.userData.mini._stamp = st;
          g.add(hitProxy(st.w * vs, st.h * vs, st.d * vs, 0, st.h * vs / 2, 0));   // the proxy rides the building — dies with it
          mn._subs.push(g); (mn._byName.get(st.n) || mn._byName.set(st.n, []).get(st.n)).push(g); }
        return miniG; }); }); })
    .catch(e => { (window.__emitErr = window.__emitErr || []).push('zone:' + (e && e.stack || e)); console.warn('CONSTRUCT — zone emit failed:', m.name, e); }); };
/* emitVox — one volume's instances + tops + mini rec. The shared body for single mounts,
   block composites, and zones: `m` supplies name/fill/x/z/flip; the grid is already assembled.
   Async — a zone's 100M-cell scan yields to the loop (chunked cooperative scan). Two culls:
   interior-bottom voxels (y=0 under full cover — their only exposed face is the model's unseen
   underside) and, with m.plate, flat [0,1] columns skip localCols (the ground plate writes its
   own rotated-rect tops — building columns stay per-column for spin/slice fidelity). */
const emitVox = async (t, m, W, H, D, vox) => {
    const vs = m._vs || (m.fill ? (m.fill * t.spec.size) / Math.max(W, D) : BLDG_VS * t.spec.scale);   // fill: span = fill × table size (_vs pins a core to its ring's scale)
    const mgen = t._mountGen, ox = m.x || 0, oz = m.z || 0;                          // mount generation at entry — staleness test for mid-emit swaps
    const mirX = m.flip !== false;                                       // .stasset grids are authored under Unity truth —
    const fx = x => mirX ? (W - 1 - x) - W / 2 + .5 : x - W / 2 + .5;      // the editor's UNITY VIEW is scale.x=-1, so a right-handed render mirrors x to match (opt out with flip:false)
    const fz = z => m.zflip ? (D - 1 - z) - D / 2 + .5 : z - D / 2 + .5;   // zone sub-stamps: raw position + z-mirrored content (the Unity L/R flip, same as the old composite stamp)
    const WH = W * H;                                                      // hoisted stride — the trace showed ~370ms of self time
    const surf = (x, y, z, b) =>                                           // inside the `at` closure alone (6 bounds checks + call cost
      !((x > 0 ? vox[b - 1] : 0) && (x < W - 1 ? vox[b + 1] : 0) &&        //  per neighbor, ~7 calls/voxel). Direct row-index reads
        (y > 0 ? vox[b - W] : 0) && (y < H - 1 ? vox[b + W] : 0) &&        //  with edge guards: OOB reads 0, same contract.
        (z > 0 ? vox[b - WH] : 0) && (z < D - 1 ? vox[b + WH] : 0));
    const under = (x, z, b0) =>                                            // interior-bottom: exposed face is only the unseen underside
      (x > 0 ? vox[b0 - 1] : 0) && (x < W - 1 ? vox[b0 + 1] : 0) &&        // (b0 = the caller's y=0 index — same guards as surf)
      (z > 0 ? vox[b0 - WH] : 0) && (z < D - 1 ? vox[b0 + WH] : 0) &&
      (H > 1 ? vox[b0 + W] : 0);
    const tick = () => new Promise(r => setTimeout(r));
    await tick();                                                        // load-order law: boot emits run mid-script-eval —
                                                                         // a macrotask defers the tail past ALL sibling files
                                                                         // (miniSettle→inB lives in 13_place.js — a microtask tail hit TDZ)
    let ng = 0, ngg = 0, gx0 = W, gx1 = -1, gz0 = D, gz1 = -1, gy1 = -1;
    const colYs = new Array(W * D);                                      // per-column voxel ys — slice/rotation-aware tops need the list
    let slot = performance.now();                                        // work-budget yields — ~8ms wall-clock slices self-size
    for (let y = 0; y < H; y++) {                                        // to the machine (a fixed 3M-cell budget ran 30–150ms
      for (let z = 0; z < D; z++) { const rb = W * (y + H * z); for (let x = 0; x < W; x++) {
      const id = vox[rb + x]; if (!id) continue;                         // per chunk in the trace — past every frame budget)
      if (x < gx0) gx0 = x; if (x > gx1) gx1 = x; if (z < gz0) gz0 = z; if (z > gz1) gz1 = z; if (y > gy1) gy1 = y;
      (colYs[x + W * z] = colYs[x + W * z] || []).push(y);
      if (surf(x, y, z, rb + x) && !(y === 0 && under(x, z, rb + x))) { ng++; if (BLDG_GLASS.has(id)) ngg++; }
      } const n = performance.now(); if (n - slot > 8) { slot = n; await tick(); } } }
    if (t._mountGen !== mgen) return null;                                         // swapped mid-scan — attaching now would ghost over the new model
    const miniG = new THREE.Group(); miniG.position.set(ox, m._parent ? (m._py || 0) : tableTop(t), oz); (m._parent || t.g).add(miniG);   // _parent = a sub-mini inside a composite (zone stamps); fresh top otherwise — the boot lift-restore may land mid-emit
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const clipMin = { value: new THREE.Vector3(-1e9, -1e9, -1e9) }, clipMax = { value: new THREE.Vector3(1e9, 1e9, 1e9) };
    const mkClipMat = base => { const m = base.clone();                  // per-model clone → own slice uniforms
      m.onBeforeCompile = sh => { sh.uniforms.uVoxClipMin = clipMin; sh.uniforms.uVoxClipMax = clipMax;
        sh.vertexShader = sh.vertexShader
          .replace('#include <common>', '#include <common>\nvarying vec3 vVoxOrigin;')
          .replace('#include <begin_vertex>', '#include <begin_vertex>\nvVoxOrigin = vec3(instanceMatrix[3]);');
        sh.fragmentShader = sh.fragmentShader
          .replace('#include <common>', '#include <common>\nvarying vec3 vVoxOrigin;\nuniform vec3 uVoxClipMin;\nuniform vec3 uVoxClipMax;')
          .replace('#include <clipping_planes_fragment>', `#include <clipping_planes_fragment>
            if (vVoxOrigin.x < uVoxClipMin.x || vVoxOrigin.y < uVoxClipMin.y || vVoxOrigin.z < uVoxClipMin.z ||
                vVoxOrigin.x >= uVoxClipMax.x || vVoxOrigin.y >= uVoxClipMax.y || vVoxOrigin.z >= uVoxClipMax.z) discard;`); };
      return m; };
    const opaque = (ng - ngg) || 1;
    const imParts = Math.max(1, Math.min(8, Math.ceil(opaque / 120e3)));   // split big composites into ≤~120k-instance parts —
    const imP = [];                                                        // a monolithic InstancedMesh uploads its whole matrix
    for (let i = 0; i < imParts; i++) {                                    // buffer in one ~115ms createBuffer hit; the staggered
      const pm = new THREE.InstancedMesh(geo, mkClipMat(new THREE.MeshLambertMaterial()), Math.ceil(opaque / imParts));
      pm.count = 0; imP.push(pm); }                                        // reveal below lands each part's upload on its own frame
    const imG = new THREE.InstancedMesh(geo, mkClipMat(window.__glassMat), ngg || 1);   // glass capacity = glass count — a
                                                                                     // zone's ng-size glass buffer wasted ~60MB
    const M = new THREE.Matrix4(), C = new THREE.Color(), dflt = new THREE.Color(.55, .55, .55);
    let no = 0, gi = 0;
    for (let y = 0; y < H; y++) {
      for (let z = 0; z < D; z++) { const rb = W * (y + H * z); for (let x = 0; x < W; x++) {
      const id = vox[rb + x]; if (!id) continue;
      if (!surf(x, y, z, rb + x) || (y === 0 && under(x, z, rb + x))) continue;
      M.makeScale(vs, vs, vs).setPosition(fx(x) * vs, (y + .5) * vs, fz(z) * vs);
      const col = BLDG_MAT[id]; C.setRGB(col ? col[0] : .55, col ? col[1] : .55, col ? col[2] : .55);
      if (BLDG_GLASS.has(id)) { imG.setMatrixAt(gi, M); imG.setColorAt(gi, C); gi++; }
      else { const pm = imP[Math.min(imParts - 1, (no * imParts / opaque) | 0)];
        pm.setMatrixAt(pm.count, M); pm.setColorAt(pm.count, C); pm.count++; no++; }
      } const n = performance.now(); if (n - slot > 8) { slot = n; await tick(); } } }
    imG.count = gi; imP.forEach(p => p.userData.miniVox = true); imG.userData.miniVox = true;   // flag the miniature's instanced walls — rayPruned skips them whole (426K matrix tests per ray)
    if (gi) miniG.add(imG);
    imP.forEach((p, i) => { p.visible = !i; miniG.add(p); });              // part 0 pops with the mount; the rest reveal
    const px0 = (Math.min(fx(gx0), fx(gx1)) - .5) * vs, px1 = (Math.max(fx(gx0), fx(gx1)) + .5) * vs,
      pz0 = (Math.min(fz(gz0), fz(gz1)) - .5) * vs, pz1 = (Math.max(fz(gz0), fz(gz1)) + .5) * vs;
    const _bsph = new THREE.Sphere(                                       // O(1) bounds — the lazy compute iterates
      new THREE.Vector3((px0 + px1) / 2, (gy1 + 1) * vs / 2, (pz0 + pz1) / 2),  // every instance on first frustum test
      Math.hypot(px1 - px0, (gy1 + 1) * vs, pz1 - pz0) / 2 + vs);           // (1.36M matrices = a guaranteed first-look hitch)
    imP.forEach(p => p.boundingSphere = _bsph); imG.boundingSphere = _bsph;
    if (gy1 >= 0 && !m.noProxy) {                                         // aim proxy = occupied bounds — the dot rests ON the model
      miniG.add(hitProxy(px1 - px0, (gy1 + 1) * vs, pz1 - pz0, (px0 + px1) / 2, (gy1 + 1) * vs / 2, (pz0 + pz1) / 2)); }
    const localCols = [];                                                // grid columns → local offsets + the ys list
    for (let z = 0; z < D; z++) { for (let x = 0; x < W; x++) {
      const ys = colYs[x + W * z]; if (!ys) continue;
      if (m.plate && ys.length === 2 && ys[0] === 0 && ys[1] === 1) continue;   // flat ground — the plate writes these tops
      localCols.push({ x, z, dx: fx(x) * vs, dz: fz(z) * vs, ys }); }
      const n = performance.now(); if (n - slot > 8) { slot = n; await tick(); } }
    miniG.userData.mini = { name: m.name, dims: [W, H, D], vox: ng, scale: vs / BLDG_VS, fill: m.fill, vs, _blkM: m._blkM, static: !!m.static,
      localCols, plate: m.plate ? { x0: px0, x1: px1, z0: pz0, z1: pz1, y: 1 } : null,
      written: new Set(), spin: 0, topTheta: 0, fx, mirX, axis: 'y',
      slice: { x: [0, W - 1], y: [0, H - 1], z: [0, D - 1] }, clipMin, clipMax };
    if (t._mountGen !== mgen || (m._parent && m._parent.parent !== t.g)) { (m._parent || t.g).remove(miniG); return null; }   // swapped mid-emit — the unflagged group survived mountModel's cleanup (or its parent detached); bail before it writes tops
    miniSyncSlice(miniG); await miniSyncTopsQ(t, miniG, m._parent ? _effOf(m._parent, miniG) : null);   // the model joins the host's surface truth — chunked; a sub-mini projects through its parent's transform
    miniG.position.y = m._parent ? (m._py || 0) : tableTop(t);           // settle on the CURRENT top — entry's capture predates a mid-emit lift-restore; the mount lands on its pedestal's real height
    miniSettle(t);                                                       // tops are truth — guests re-derive under the new map (a mount/swap left them on the old)
    for (let i = 1; i < imP.length && t._mountGen === mgen; i++) {       // staggered reveal — each part's first draw uploads
      imP[i].visible = true; await tick(); }                               // only its own slice of the matrix buffer, one frame apart
    return miniG;
  };
/* miniSyncSlice — the editor's xyz window, same contract: a per-axis index range shader-clips
   instances whose origins fall outside. Clip bounds are MODEL-LOCAL (mirrored x handled via fx). */
const miniSyncSlice = mdl => { const mn = mdl.userData.mini, s = mn.slice, vs = mn.vs, D = mn.dims[2];
  const lx0 = Math.min(mn.fx(s.x[0]), mn.fx(s.x[1])), lx1 = Math.max(mn.fx(s.x[0]), mn.fx(s.x[1]));
  mn.clipMin.value.set((lx0 - .5) * vs, s.y[0] * vs, (s.z[0] - D / 2) * vs);
  mn.clipMax.value.set((lx1 + .5) * vs, (s.y[1] + 1) * vs, (s.z[1] + 1 - D / 2) * vs); };
/* miniSyncTops — rewrite the model's host tops under the CURRENT rotation + slice: written keys
   revert to felt, then surviving columns re-project (rotated offsets, top = tallest y in window).
   A `plate` model (zones/block composites — full-coverage ground slab) writes its flat top as a
   rotated rect of columns first; per-column localCols only carry the raised content above it. */
/* _effOf — a sub-mini's effective host-space transform: parent pos + child offset rotated by the
   parent's rotation, base height = group's top + the child's own lift (zone stamps sit on the
   ground slab's 2-cell top). Top-level callers pass null → the model's own transform. */
const _effOf = (p, ch) => { const c = Math.cos(p.rotation.y), s = Math.sin(p.rotation.y);
  return { th: p.rotation.y + ch.rotation.y,
    ox: p.position.x + ch.position.x * c - ch.position.z * s,
    oz: p.position.z + ch.position.x * s + ch.position.z * c,
    by: p.position.y + ch.position.y }; };
const _miniTopsHead = (t, mdl, eff) => { const mn = mdl.userData.mini;
  const wr = [...mn.written]; mn.written.clear();                                  // snapshot — callers chunk the revert
  const th = eff ? eff.th : mdl.rotation.y, c = Math.cos(th), sn = Math.sin(th),
    ox = eff ? eff.ox : mdl.position.x, oz = eff ? eff.oz : mdl.position.z,
    by = eff ? eff.by : mdl.position.y;                                            // host-local base y — a top mini's y IS tableTop
  return { mn, ox, oz, c, sn, wr, by }; };
const _miniTopsRevert = (t, wr, i0, i1) => { const v = tableTop(t);                // written keys drop back to felt
  for (let i = i0; i < i1; i++) t.rec.tops.set(wr[i], v); };                       // (~250k Map.set on a zone — chunkable)
const _miniTopsPlateRect = (t, mn, ox, oz, c, sn, by) => { const s = mn.slice, D = mn.dims[2];
  if (!(mn.plate && s.y[0] <= mn.plate.y && s.y[1] >= mn.plate.y)) return null;   // ground plate survives the y window → fill its rect
  const sx0 = Math.min(mn.fx(s.x[0]), mn.fx(s.x[1])) - .5, sx1 = Math.max(mn.fx(s.x[0]), mn.fx(s.x[1])) + .5,   // slice window, local
    rx0 = Math.max(mn.plate.x0, sx0 * mn.vs), rx1 = Math.min(mn.plate.x1, sx1 * mn.vs),
    rz0 = Math.max(mn.plate.z0, (s.z[0] - D / 2) * mn.vs), rz1 = Math.min(mn.plate.z1, (s.z[1] + 1 - D / 2) * mn.vs);
  if (!(rx0 < rx1 && rz0 < rz1)) return null;
  const cs = [[rx0, rz0], [rx1, rz0], [rx0, rz1], [rx1, rz1]].map(([dx, dz]) => [ox + dx * c - dz * sn, oz + dx * sn + dz * c]);
  return { rx0, rx1, rz0, rz1, v: by + (mn.plate.y + 1) * mn.vs,
    ix0: Math.round(Math.min(...cs.map(p => p[0])) * 200), ix1: Math.round(Math.max(...cs.map(p => p[0])) * 200),
    iz0: Math.round(Math.min(...cs.map(p => p[1])) * 200), iz1: Math.round(Math.max(...cs.map(p => p[1])) * 200) }; };
const _miniTopsPlateFill = (t, mn, ox, oz, c, sn, R, ix0, ix1) => {
  for (let ix = Math.max(R.ix0, ix0); ix <= Math.min(R.ix1, ix1); ix++)
    for (let iz = R.iz0; iz <= R.iz1; iz++) {
      const dx = (ix / 200 - ox) * c + (iz / 200 - oz) * sn, dz = -(ix / 200 - ox) * sn + (iz / 200 - oz) * c;   // world → local
      if (dx >= R.rx0 && dx <= R.rx1 && dz >= R.rz0 && dz <= R.rz1) {
        const k = TOPK(ix, iz); if (R.v > (t.rec.tops.get(k) ?? -1e9)) { t.rec.tops.set(k, R.v); mn.written.add(k); } } } };
const _miniTopsCols = (t, mn, ox, oz, c, sn, i0, i1, by) => { const s = mn.slice;
  for (let i = i0; i < i1; i++) { const col = mn.localCols[i];
    if (col.x < s.x[0] || col.x > s.x[1] || col.z < s.z[0] || col.z > s.z[1]) continue;
    let ym = -1; for (const y of col.ys) if (y >= s.y[0] && y <= s.y[1] && y > ym) ym = y;
    if (ym < 0) continue;
    const lx = ox + col.dx * c - col.dz * sn, lz = oz + col.dx * sn + col.dz * c;
    const k = TOPK(Math.round(lx * 200), Math.round(lz * 200)), v = by + (ym + 1) * mn.vs;
    if (v > (t.rec.tops.get(k) ?? -1e9)) t.rec.tops.set(k, v);           // several model cells share a 5mm column — keep the true max
    mn.written.add(k); } };
const _miniTopsOne = (t, mdl, eff) => { const { mn, ox, oz, c, sn, wr, by } = _miniTopsHead(t, mdl, eff);
  _miniTopsRevert(t, wr, 0, wr.length);
  const R = _miniTopsPlateRect(t, mn, ox, oz, c, sn, by); if (R) _miniTopsPlateFill(t, mn, ox, oz, c, sn, R, -1e9, 1e9);
  _miniTopsCols(t, mn, ox, oz, c, sn, 0, mn.localCols.length, by); };
const miniSyncTops = (t, mdl) => { _miniTopsOne(t, mdl, null);
  (mdl.userData.mini._subs || []).forEach(sub => _miniTopsOne(t, sub, _effOf(mdl, sub))); };   // a composite's children re-project under the parent's spin too
/* chunked twin for the remount path — the zone's revert + columns + ~440-col plate rect would
   otherwise freeze ~100ms behind a variant cycle; slice/spin callers keep the sync version. */
const _miniTopsOneQ = async (t, mdl, eff) => { const { mn, ox, oz, c, sn, wr, by } = _miniTopsHead(t, mdl, eff);
  for (let i = 0; i < wr.length; i += 16e3) { _miniTopsRevert(t, wr, i, Math.min(i + 16e3, wr.length)); await new Promise(r => setTimeout(r)); }
  const R = _miniTopsPlateRect(t, mn, ox, oz, c, sn, by);
  if (R) for (let ix = R.ix0; ix <= R.ix1; ix += 48) { _miniTopsPlateFill(t, mn, ox, oz, c, sn, R, ix, ix + 47); await new Promise(r => setTimeout(r)); }
  for (let i = 0; i < mn.localCols.length; i += 8e3) {
    _miniTopsCols(t, mn, ox, oz, c, sn, i, Math.min(i + 8e3, mn.localCols.length), by);
    await new Promise(r => setTimeout(r)); } };
const miniSyncTopsQ = async (t, mdl, eff) => { await _miniTopsOneQ(t, mdl, eff || null);
  for (const sub of (mdl.userData.mini._subs || [])) await _miniTopsOneQ(t, sub, _effOf(mdl, sub)); };
/* miniSpinSet — the turntable: rate in rad/s, toggling the active rate stops it. Tops re-project
   every >.02 rad during spin (the render loop owns the integration) and exactly on stop. */
const miniSpinSet = rate => { const t = padTable(), mdl = t && t.g.children.find(c => c.userData.mini && !c.userData.mini.static);
  if (!mdl) return; const mn = mdl.userData.mini;
  mn.spin = (mn.spin === rate) ? 0 : rate;
  if (!mn.spin) { mn.topTheta = mdl.rotation.y; miniSyncTops(t, mdl); miniSettle(t); } };   // exact tops on stop → riders re-seat
/* miniRotReset — home the easel: stop any spin, face the model at rotY 0, exact tops re-sync. */
const miniRotReset = () => { const t = padTable(), mdl = t && t.g.children.find(c => c.userData.mini && !c.userData.mini.static);
  if (!mdl) return; const mn = mdl.userData.mini;
  mn.spin = 0; mdl.rotation.y = 0; mn.topTheta = 0; miniSyncTops(t, mdl); miniSettle(t); };
/* miniSettle — tops-change law: after an exact sync, anything standing above the slab inside
   the footprint re-derives its seat — stale reads (lagged spin tops, a swap, a cut) leave
   riders embedded or floating; the measured map is the truth, settle to it. */
const miniSettle = t => { const H = tableTop(t);
  PLACED.forEach(q => { if (q === t.rec || q === held || q.mount || q.g.parent !== scene) return;
    if (inB(q, t.rec.bbox) && q.y0 > H + .005) {
      const s = placeSurf(q.x, q.z, new Set([q]), { surfOnly: q.surf });
      if (Math.abs(s - q.y0) > 1e-4) { q.y0 = s; q.g.position.y = s; } } }); };
/* sliceStep — nudge the active slice bound by dim/16 steps (min 1), clamped against its twin. */
const miniSliceStep = (bound, dir) => { const t = padTable(), mdl = t && t.g.children.find(c => c.userData.mini && !c.userData.mini.static);
  if (!mdl || t.spec.noSlice) return; const mn = mdl.userData.mini, ax = mn.axis || 'y', dim = mn.dims['xyz'.indexOf(ax)], s = mn.slice[ax],
    st = Math.max(1, dim >> 4), i = bound === 'min' ? 0 : 1;
  s[i] = Math.max(i ? s[0] : 0, Math.min(i ? dim - 1 : s[1], s[i] + dir * st));
  miniSyncSlice(mdl); miniSyncTops(t, mdl); miniSettle(t); };
const miniSliceReset = () => { const t = padTable(), mdl = t && t.g.children.find(c => c.userData.mini && !c.userData.mini.static);
  if (!mdl || t.spec.noSlice) return; const mn = mdl.userData.mini;
  mn.slice = { x: [0, mn.dims[0] - 1], y: [0, mn.dims[1] - 1], z: [0, mn.dims[2] - 1] };
  miniSyncSlice(mdl); miniSyncTops(t, mdl); miniSettle(t); };
/* mountModel — the easel's swap verb: unmount the old mini (its tops columns revert to felt),
   mount the catalog spec. models[] always reads as "what's on the table now". */
const mountModel = (t, mspec) => {
  t._mountGen = (t._mountGen || 0) + 1;                                                // generation — an in-flight emit of a swapped-out model bails instead of ghosting a second composite
  t.g.children.filter(c => c.userData.mini && !c.userData.mini.static).forEach(c => {  // static minis (the street ring) survive every swap — cars stay parked through it
    const wr = [...(c.userData.mini.written || [])];
    (c.userData.mini._subs || []).forEach(s => wr.push(...(s.userData.mini.written || [])));   // zone sub-minis own their own written sets — revert theirs too or they ghost on the felt
    setTimeout(async () => { for (let i = 0; i < wr.length; i += 16e3) { _miniTopsRevert(t, wr, i, Math.min(i + 16e3, wr.length)); await new Promise(r => setTimeout(r)); } });   // ~250k felt reverts on a zone — chunked across turns
    for (let i = PLACED.length - 1; i >= 0; i--) if (PLACED[i].g && PLACED[i].g.parent === c) PLACED.splice(i, 1);   // parked overlays die with their model — no ghost hosts
    const dead = c.children.slice(); t.g.remove(c);                          // detach now; each child's dispose frees on its own
    dead.forEach(ch => setTimeout(() => { ch.traverse ? ch.traverse(o => { o.dispose && o.dispose(); o.material && o.material.dispose && o.material.dispose(); })
      : (ch.dispose && ch.dispose(), ch.material && ch.material.dispose && ch.material.dispose()); }, 0)); });      // turn — a zone-sized dispose isn't one ~100ms block
  t.g.children.filter(c => c.userData.mini && c.userData.mini.static).forEach(c => miniSyncTops(t, c));   // the core's revert dropped overlapping keys to felt — restore the ring's tops underneath
  t.spec.models = [mspec];
  const vb = mspec.name && mspec.name.split('__');                                 // mount-driven preview law — a `__`
  if (vb && vb[1]) _previewOf[vb[0]] = mspec.name; else delete _previewOf[mspec.name];   // name staged on ANY mount path
  return (t._mountP = (mspec.zone ? emitZone : mspec.slots ? (t._ringG ? emitCore : emitBlock) : emitBldg)(t, mspec));   // tracked — boot awaits it before extras/fixpoint read tops
};
MANIFEST.tables.forEach(spec => { const t = emitTable(spec);
  const savedLift = +localStorage.getItem('dvm_lift:' + spec.id);           // the pistons remember their reach
  if (savedLift) t._savedLift = savedLift;                                  // applied in boot AFTER overrides — a rider's saved seat precedes its ride (eval-time calls are still TDZ landmines: liftRiders reaches late-bound helpers)
  const saved = localStorage.getItem('dvm_model:' + spec.id), cat = spec.catalog || spec.models,
    pick = cat.find(m => m.name === saved) || spec.models[0];
  if (spec.ring) t._mountP = emitRing(t, pick.fill).then(ringG => {               // the street exhibit is the table's — ring first, cars on it, then the interior core
    if (!ringG) return null;
    t._ringG = ringG;
    return mountParked(t, ringG, spec.parked || [])
      .then(() => mountModel(t, pick)); });                                     // mountModel rewrites t._mountP to the core emit — still the last promise standing
  else mountModel(t, pick); });
/* ═══ LIVE SYNC — the voxel editor's strokes trickle in over BroadcastChannel('scms-voxel'):
   every pushHistory() posts a vox-delta ({name,dims,ops:[[x,y,z,mid]]}); loads/dim-changes/undo-
   recovery post vox-full ({name,dims,vox:ArrayBuffer}). Messages patch _stCache (the fetch
   layer's own truth — every emit re-reads it), then remount each mini listing the file in
   _deps — slice/spin/rotY carry over so the exhibit redraws in place. Rebuilds debounce per
   table; mountModel's _mountGen kills mid-flight emits of superseded rebuilds. The editor can
   demand a baseline with vox-hello/need-full (Construct asks for full on a dims mismatch). ═══ */
const voxChan = ('BroadcastChannel' in window) ? new BroadcastChannel('scms-voxel') : null;
const remountMini = t => { const mdl = t.g.children.find(c => c.userData.mini && !c.userData.mini.static);
  const keep = mdl ? { slice: JSON.parse(JSON.stringify(mdl.userData.mini.slice)), spin: mdl.userData.mini.spin, rotY: mdl.rotation.y } : null;
  return mountModel(t, t.spec.models[0]).then(g => {
    if (g && keep) { const mn = g.userData.mini;
      if (keep.slice.x[1] < mn.dims[0] && keep.slice.y[1] < mn.dims[1] && keep.slice.z[1] < mn.dims[2]) mn.slice = keep.slice;
      mn.spin = keep.spin; g.rotation.y = keep.rotY;
      miniSyncSlice(g); return miniSyncTopsQ(t, g).then(() => { miniSettle(t); return g; }); }
    return g; }); };
const _rebuildT = {};
/* restampZone — surgical dep rebuild: a stamped name's sub-minis re-emit in place while the
   ground composite and every other stamp hold. ~150k cells per stamp instead of the full
   ~37M-cell re-bake — a single-building stroke lands in ~200ms. stassetFetch resolves
   _previewOf, so variant cycles repaint the zone surgically too (canonical name → variant grid).
   A full remount mid-emit kills the batch via emitVox's _mountGen/_parent checks. */
const restampZone = async (t, zoneG, name) => { const mn = zoneG.userData.mini, vs = mn.vs,
    W2 = mn.dims[0], D2 = mn.dims[2];
  const f = await stassetFetch(name);
  for (const child of (mn._byName.get(name) || []).slice()) { const cm = child.userData.mini, st = cm._stamp;
    (cm.written || []).forEach(k => t.rec.tops.set(k, tableTop(t)));         // drop the old stamp's tops — a building's cols only
    const si = mn._subs.indexOf(child); if (si >= 0) mn._subs.splice(si, 1);
    const bl = mn._byName.get(name), bi = bl.indexOf(child); if (bi >= 0) bl.splice(bi, 1);
    zoneG.remove(child);
    setTimeout(() => child.traverse(o => { o.dispose && o.dispose(); o.material && o.material.dispose && o.material.dispose(); }));   // dispose off the hot turn
    const g = await emitVox(t, { name, _vs: vs, flip: false, zflip: true, _parent: zoneG, _py: 2 * vs, noProxy: true,
      x: (st.x + st.w / 2 - W2 / 2) * vs, z: (st.z + st.d / 2 - D2 / 2) * vs }, f.W, f.H, f.D, f.vox);
    if (!g) return;                                                          // a full remount landed mid-emit — it owns the subs now
    g.userData.mini._deps = new Set([name]); g.userData.mini._stamp = st;
    g.add(hitProxy(st.w * vs, f.H * vs, st.d * vs, 0, f.H * vs / 2, 0));
    mn._subs.push(g); (mn._byName.get(name) || mn._byName.set(name, []).get(name)).push(g); }
  miniSettle(t); };
const rebuildDeps = name => TABLES.forEach(t => {                       // debounce per table — a paint session is many strokes
  const mdl = t.g && t.g.children.find(c => c.userData.mini && !c.userData.mini.static), deps = mdl && mdl.userData.mini._deps;
  const wants = mdl ? deps && (deps.has(name) || [...deps].some(d => _previewOf[d] === name))   // a variant rebuilds its previewers too
                  : t.spec.models[0] && t.spec.models[0].name === name; // mount died pre-sync (file 404'd) — the broadcast IS the grid; retry it
  if (wants) { const heavy = mdl.userData.mini.dims[0] * mdl.userData.mini.dims[2] > 2e5;   // zone-scale composite — during a
    clearTimeout(_rebuildT[t.spec.id]); _rebuildT[t.spec.id] = setTimeout(() => {
      const mdl2 = t.g && t.g.children.find(c => c.userData.mini && !c.userData.mini.static), mn2 = mdl2 && mdl2.userData.mini;
      const can = mn2 && mn2._byName && (mn2._byName.has(name) ? name          // surgical path — the changed building's
        : [...mn2._byName.keys()].find(k => _previewOf[k] === name));          // sub-minis restamp alone (variant-name hits resolve to canonical)
      if (can) restampZone(t, mdl2, can); else remountMini(t); },
      160 + TABLES.indexOf(t) * 140 + (heavy ? 420 : 0)); } });   // longer quiet for heavy composites — a stroke stream waits it out
const liveCatalog = name => { const t = TABLES.find(t => t.spec.id === 'primary');   // a WIP the studio never shipped is still exhibitable —
  if (t && !(t.spec.catalog || []).some(e => e.name === name))                       // the broadcast primes _stCache, so mountModel works file-free
    (t.spec.catalog = t.spec.catalog || []).push({ name, fill: .75 }); };
if (voxChan) { voxChan.onmessage = e => { const m = e.data || {};
  if (!m.name) return;
  liveCatalog(m.name);
  if (m.type === 'vox-full') _stCache[m.name] = Promise.resolve({ W: m.dims[0], H: m.dims[1], D: m.dims[2], vox: new Uint16Array(m.vox) });
  else if (m.type === 'vox-delta') {
    if (!_stCache[m.name]) return void voxChan.postMessage({ type: 'need-full', name: m.name });
    _stCache[m.name] = _stCache[m.name].then(f => {
      if (f.W !== m.dims[0] || f.H !== m.dims[1] || f.D !== m.dims[2]) { voxChan.postMessage({ type: 'need-full', name: m.name }); return f; }
      m.ops.forEach(([x, y, z, id]) => { if (x >= 0 && x < f.W && y >= 0 && y < f.H && z >= 0 && z < f.D) f.vox[x + f.W * (y + f.H * z)] = id; });
      return f; }); }
  else return;
  rebuildDeps(m.name); };
  voxChan.postMessage({ type: 'vox-hello' }); }                          // open-after-edits handshake — a live editor answers with vox-full
/* file-deposited lane — the same doorbell the agent ears ride: /events emits {"file":"vox:<name>"}
   whenever a voxel_items JSON changes, so a daemon's /save/voxel write lands here without the
   editor open. Re-fetch the file → prime the cache → catalog entry + dependent rebuild. */
if ('EventSource' in window) { const es = new EventSource('/events');
  es.onmessage = e => { const f = (String(e.data).match(/"file":"(.*?)"/) || [])[1];
    if (f && f.startsWith('vox:')) { const name = f.slice(4);
      _stCache[name] = fetch('/voxel/' + name).then(r => r.ok ? r.json().then(_jsonToVox) : Promise.reject(r.status));
      liveCatalog(name); rebuildDeps(name); } }; }
/* cold-boot catalog — deposits made while the page was closed doorbell nothing, so the boot
   merges the /models index itself. assetType 'building' only: props/vehicles/characters don't
   belong in the exhibit cycle; __ variants land here too (V◀V▶ owns their row). */
fetch('/models').then(r => r.ok ? r.json() : null).then(j => j &&
  (j.models || []).forEach(m => { if (m && m.name && m.assetType === 'building') liveCatalog(m.name); }));
