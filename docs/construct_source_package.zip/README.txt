CONSTRUCT SOURCE PACKAGE — Steel City Mob Sim (post-perf-pass snapshot)
========================================================================
Page: docs/construct.html (served at http://127.0.0.1:8723/construct.html)
Renderer: three.js r160 — SELF-HOSTED at docs/vendor/three.module.js (importmap)
Loop: requestAnimationFrame in construct/14_loop.js

ARCHITECTURE (read first)
-------------------------
construct.html is a thin HUD shell (markup + inline CSS + importmap) that loads
19 CLASSIC deferred scripts from construct/ in numeric order. They are NOT
modules — they share ONE page-level lexical scope.

CRITICAL: load order is load-bearing. A top-level statement in file N cannot
reference a let/const declared in file N+k (TDZ). Runtime function bodies may
reference later declarations freely. Known landmine: ghost/aimDot live in
12_carry.js — 07_pov_aim.js must touch them lazily inside aimStep().

FILE ROLES
----------
01_shell.js        scene, renderer (antialias, hi-perf, DPR cap 2), lights, torch, window.voxEmit (real-size asset emit)
02_placed.js       PLACED registry + surface maps (TOPK keys), footB, topOf, emitAsset
03_tables.js       tables, voxel composites, emitVox, miniSyncTops/Q, block traffic, parked cars — largest file, hot paths
04_pad.js          debug pad UI + padProbe()
05_pose_engine.js  follower/instance pose math
06_followers.js    follower NPC rigs (DynamicDrawUsage instancing)
07_pov_aim.js      aim raycast, rayPruned scene prune, aim dot
08_panels.js       panels + mannequin kiosk, kioskProbe()
09_live_ctl.js     live agent control
10_self_solids.js  self body + colliders
11_input.js        input + pointer lock (place-mode keys live here)
12_carry.js        carry/drop ghost, dropTarget() march, nearestPick()
13_place.js        placement mode, placeDrop/placeGrab, settleOrphans, undo
14_loop.js         MAIN LOOP: spin sync, probes, compass HUD, selBox
15_boot.js         boot/warmup: rAF HUD-paint gate, compile+veil-covered render, fixpoint re-seat
16_probe.js        window.__probe diagnostics API
17_lamps.js        exhibit lamps + light switches, swProbe()
18_options.js      options overlay (capture-phase keydown while open)
19_chat.js         chat tab, chatPin/chatHide (hide+blur — hidden inputs keep focus in Chrome)

PERF STATE (post-audit)
-----------------------
- emitVox: ~8ms wall-clock yield slices; inlined voxel accessors; opaque
  instances split into <=~120k-instance InstancedMesh parts with staggered
  reveal (createBuffer uploads land one per frame).
- miniSyncTops during spin: STILL synchronous (~700k Map ops/sync on zone
  tables) — the next lever is reusing chunked miniSyncTopsQ on the spin path.
- First-draw createBuffer: mitigated by the mesh split; remains inherent.
- Web Worker emit: deferred — voxEmit coupled to the scene graph.
- KHR_parallel_shader_compile warning is informational.

KNOWN BUGS FIXED THIS PASS (see docs/known_issues/runtime/)
-----------------------------------------------------------
- CONSTRUCT_ENTER_DROP_STACK_OVERFLOW: Math.max(...tops.values()) arg-spread
  overflowed the call stack on 231k-column hosts — Enter couldn't plant the
  studio table. Fixed via topOf().
- CONSTRUCT_CHAT_FIELD_STEALS_KEYBOARD: hidden chat <input> kept DOM focus and
  ate all keys. Fixed via chatHide() blur.

PROBE HARNESS
-------------
_run.mjs / _cdp.mjs        runner + CDP driver (headless Chrome, temp profile)
_place_enter_sweep.mjs     grab-everything + Enter sweep (found the stack bug)
_voxsync_check.mjs         29-assert emit/mount/restamp suite (not in zip? check)
_perf_check.mjs            frame/GC sampler
_gc_check.mjs              allocation churn probe
_roadprof_scan.mjs         render-loop profile scan
_construct_check.mjs       smoke check
